# SupeRR Selector S2 – Pressure-Performance Model (v3)

**v3 = v2 + robust ranking:** pessimistic bootstrap rank, tier penalty / Tier C watch-list, batter-bowler role gate, recency weight. See `outputs/V3_CHANGES.md`.

Scores **every** batter and bowler in the IPL + T20I data (2022 onwards) on performance under pressure. It does not pick a final list:
it produces one consistent, evidence-weighted score table. The available pool (post-retention auction list) is applied afterwards with `select_pool.py`.

## Run order
```
python run_pipeline.py --data-dir "../Data Pack" --out ../shared_outputs     # shared data pipeline (once)
python run_all.py                                                              # full model, ~20 min (300 bootstrap draws)
python run_all.py --nboot 20 --nsplits 3                                       # quick test run
python select_pool.py --pool target_pool.csv --top 50                          # after the pool is known (pool file may carry a `role` column)
python rerank.py                                                               # re-apply ranking rules (config.py) to existing outputs, no re-fit
```
Every tunable number lives in `config.py` (single source of truth). Deterministic (fixed seed).

## Files
| file | role |
|---|---|
| `config.py` | all thresholds, priors, tiers, seeds |
| `pressure.py` | delivery-level pressure (batting & bowling), venue factor, free-hit state |
| `metrics.py` | context residuals, venue adjustment, empirical-Bayes shrinkage, relief / over-success |
| `reliab.py` | split-half reliability, reliability-derived weights |
| `scoring.py` | tiers, no-signal gate, scores, phase profiles, roles/context |
| `validate.py` | whole-score reliability (random match splits), sensitivity helpers |
| `run_all.py` | end-to-end run → `outputs/` |
| `ranking.py` | v3: tier penalty, pessimistic rank, role resolution + gate, Tier C split |
| `rerank.py` | v3: apply the ranking rules to existing outputs without re-running the model |
| `select_pool.py` | filter to an available pool; role-gated, penalised, pessimistic-rank top-N lists + Tier C watch-list |

## Outputs (`outputs/`)
- `rankings_batters_all.csv`, `rankings_bowlers_all.csv`: all players with pressure data. Key columns:
  - `final`, `level`, `level_serious`, `level_high`, `consistency`: scores (0–100 percentiles vs the Tier-A reference pool)
  - `tier`: **A** = full evidence (reference pool), **B** = moderate, **C** = thin (scores are shrunk toward average; treat as low-confidence)
  - `role` (batters: top / middle / finisher), `primary_phase`, `specialist_in`, `pace_or_spin` (bowlers), `level_PP/MID/DEATH` (bowler phase profiles)
  - `origin_hint`, `ipl_team`, `last_ipl_match`: context for the pool filter (no nationality field exists in the data; origin is inferred from T20I team)
  - `pressure_minus_usual_*`: the official "vs usual level" comparison with an 80% interval (reported, zero weight in the score)
  - `boot_*`: rank intervals / probabilities from 300 match-level bootstrap draws (performance layer; pressure bands held fixed)
- `boot_scores_*.csv.gz`: per-draw scores so `select_pool.py` can compute rank intervals **inside** any pool
- `validation_summary.json`, `sensitivity.csv`, `whole_score_split_half_by_split.csv`, `pressure_band_evidence.txt`

## What changed vs v1 (all from the independent review and the tests behind it)
Relief baseline now conditions on innings and entry phase; bowler over-success is descriptive only (no detectable signal);
venue factor in the par path plus leave-one-player-out venue adjustment of residuals; pooled within-player variance in the empirical-Bayes estimator;
free hit persists through wides; batter consistency needs ≥ 6 pressure balls; automatic no-signal gate (a metric-band with no detectable
between-player variance scores a neutral 50 for everyone instead of ranking noise); tiers instead of a hard eligibility cut so thin-sample pool players are
visible with honest confidence; 300 bootstrap draws; one config; phase profiles for bowlers.

## Honest limits
Individual top-N placement is not stable (see `validation_summary.json` → `whole_score_split_half`). Use ranks as tiers, not as precise orderings.
"Pressure minus usual" does not replicate across matches, so it is reported but not scored. No auction price, availability or squad-fit logic is included.
