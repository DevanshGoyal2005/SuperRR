# Data Quality Report - shared pipeline v1.0.0

## Coverage
- Raw delivery rows: 200,999; super-over rows dropped: 38; output rows: 200,961
- Matches in matches.csv: 883; with ball data: 867; without ball data: 16 (all `no_result`-type results)
- Matches flagged `match_complete`: 843 of 867
- Matches by comp_group: {'T20I': 470, 'IPL': 367, 'OTHER_T20': 30}
- Shortened (rain/DLS) matches: 34
- Duplicate delivery keys: 0

## Validation of the rebuilt match state
- Innings with legal balls > limit: **0** (should be 0)
- Chase batting team != first-innings bowling team: **0** (should be 0)
- Target reconstruction: re-derived chase winner vs recorded winner on 833 decided matches -> **2 mismatches** [24822, 28334]
- Truncated / incomplete innings (not all-out, not full length, chase not won): 46
- Boundary flags disagreeing with bat runs: 0
- Par-curve innings by comp_group (min 30 else pooled): {'T20I': 448, 'IPL': 364, 'OTHER_T20': 30}

## Players
- Players: 958; batters with data: 888; bowlers with data: 647
- Base-eligible batters: **168**; base-eligible bowlers: **157**
- Name clashes (same name, different player_id): [{'player_id': 6922, 'player_name': 'Abdul Samad'}, {'player_id': 7338, 'player_name': 'Haider Ali'}, {'player_id': 7446, 'player_name': 'Abdul Samad'}, {'player_id': 8638, 'player_name': 'Basil Hameed'}, {'player_id': 28756, 'player_name': 'Haider Ali'}, {'player_id': 39444, 'player_name': 'Basil Hameed'}]
- Name differs between ball_by_ball and mapping file: [{'player_id': 4458, 'player_name': 'Aneurin Donald', 'name_in_mapping': 'AHT Donald'}]

## Known limitations / judgement calls
- `extras_type == 'other'` treated as no-ball (264 rows) - confirmed because it restores 6 legal balls/over and <=120/innings.
- `extras_2_runs` on no-balls (48 runs) not charged to the bowler.
- Phase uses fixed over numbers even when the match is shortened; `is_shortened` lets you exclude those.
- Wickets: `is_wicket` counts every team wicket; `bowler_wicket` and `striker_dismissed` are the attribution columns.
- Truncated innings listed above may be rain/abandonment or data gaps; filter with `match_complete`.
- Truncated examples: [{'match_id': 14130, 'innings': 1, 'inn_legal': 119, 'inn_wkts': 6, 'hs_innings_total': 167}, {'match_id': 14130, 'innings': 2, 'inn_legal': 119, 'inn_wkts': 8, 'hs_innings_total': 130}, {'match_id': 14164, 'innings': 1, 'inn_legal': 119, 'inn_wkts': 8, 'hs_innings_total': 156}, {'match_id': 15409, 'innings': 2, 'inn_legal': 101, 'inn_wkts': 9, 'hs_innings_total': 87}, {'match_id': 15410, 'innings': 1, 'inn_legal': 21, 'inn_wkts': 2, 'hs_innings_total': 28}, {'match_id': 15546, 'innings': 1, 'inn_legal': 78, 'inn_wkts': 8, 'hs_innings_total': 105}, {'match_id': 15795, 'innings': 1, 'inn_legal': 72, 'inn_wkts': 4, 'hs_innings_total': 108}, {'match_id': 16754, 'innings': 1, 'inn_legal': 90, 'inn_wkts': 5, 'hs_innings_total': 95}, {'match_id': 16754, 'innings': 2, 'inn_legal': 40, 'inn_wkts': 3, 'hs_innings_total': 56}, {'match_id': 17627, 'innings': 2, 'inn_legal': 111, 'inn_wkts': 9, 'hs_innings_total': 178}, {'match_id': 17765, 'innings': 2, 'inn_legal': 23, 'inn_wkts': 3, 'hs_innings_total': 30}, {'match_id': 18532, 'innings': 2, 'inn_legal': 54, 'inn_wkts': 4, 'hs_innings_total': 75}, {'match_id': 20182, 'innings': 2, 'inn_legal': 96, 'inn_wkts': 7, 'hs_innings_total': 146}, {'match_id': 20226, 'innings': 1, 'inn_legal': 116, 'inn_wkts': 7, 'hs_innings_total': 125}, {'match_id': 21070, 'innings': 1, 'inn_legal': 116, 'inn_wkts': 5, 'hs_innings_total': 207}]