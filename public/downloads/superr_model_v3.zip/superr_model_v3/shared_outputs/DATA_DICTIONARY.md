# Data Dictionary - shared pipeline v1.0.0

## ball_features.csv.gz  (one row per delivery, super overs excluded)

State columns describe the situation **before** the delivery is bowled. Columns prefixed `hs_` are **hindsight** (known only after the match) - do not use them as real-time pressure inputs.

| column | description |
|---|---|
| `match_id` | Match key (matches.csv). |
| `comp_id` | Competition key. |
| `comp_name` | Competition name. |
| `comp_group` | IPL / T20I / OTHER_T20 (Emerging Teams Asia Cup 2024, Asia Cup Rising Stars 2025). Use for IPL-vs-T20I handling. |
| `season_year` | Calendar year of match_date. |
| `match_date` | Match date (YYYY-MM-DD). |
| `stage` | Stage text from matches.csv (League, Final, ...). |
| `is_knockout` | 1 if knock_out flag set or stage in Final/Qualifier/Eliminator/Semi Final. |
| `venue_id` | Venue key. |
| `venue_country` | Venue country. |
| `innings` | 1 = batting first, 2 = chasing. Super-over innings (3,4) are EXCLUDED. |
| `innings_ball_num` | Delivery sequence in innings (counts every delivery incl. wides/no-balls). |
| `overid` | Over number, 1-20. |
| `over_ball_num` | Delivery number within the over (can exceed 6). |
| `phase` | PP (overs 1-6), MID (7-15), DEATH (16-20). Fixed by over number even in shortened matches. |
| `batting_team_id` | Batting team key. |
| `bowling_team_id` | Bowling team key. |
| `batting_team` | Batting team name. |
| `bowling_team` | Bowling team name. |
| `striker_id` | Batter on strike (use IDs, not names: 3 names map to 2 players). |
| `striker_name` | Name as in ball_by_ball. |
| `non_striker_id` | Non-striker key. |
| `bowler_id` | Bowler key. |
| `bowler_name` | Name as in ball_by_ball. |
| `batting_type` | RHB / LHB. |
| `bowling_type` | Bowling style text. |
| `pace_or_spin` | Pace / Spin. |
| `batting_order` | Striker's batting position (1-11). |
| `striker_is_impact` | 1 if striker was an IPL Impact Player substitute in this match. |
| `bowler_is_impact` | 1 if bowler was an Impact Player substitute in this match. |
| `stroke` | Shot played (3% missing). Not used in shared features. |
| `bat_runs` | Runs off the bat (source column `runs`; includes runs off no-balls). |
| `extras_runs` | extras1_runs + extras_2_runs. |
| `total_runs` | bat_runs + extras_runs = runs added to team total. |
| `bowler_runs` | Runs charged to bowler: bat_runs + (extras1 on wides/no-balls). Byes, leg-byes, penalty excluded. Caveat: extras_2 on no-balls (48 runs in data) not charged. |
| `extras_type` | Source extras type (wide, Overstep, other, byes, legbyes, Penalty). |
| `is_wide` | 1 if wide. |
| `is_noball` | 1 if no-ball (extras_type 'Overstep' or 'other'; 'other' verified to behave as a no-ball). |
| `is_legal` | 1 if neither wide nor no-ball. Exactly 120 legal balls = full T20 innings. |
| `batter_faced` | 1 if delivery counts as a ball faced by striker (everything except wides). |
| `is_bat_four` | 1 if bat_runs==4 and flagged four. |
| `is_bat_six` | 1 if bat_runs==6 and flagged six. |
| `is_dot_batter` | 1 if batter_faced and bat_runs==0 (includes bye/leg-bye balls). |
| `is_dot_bowler` | 1 if legal and bowler_runs==0. |
| `is_wicket` | 1 if any wicket fell on the delivery (team-level wicket, incl. run-outs, retired out). |
| `dismissal_type` | Source dismissal text. |
| `dismissed_player_id` | Player dismissed (may be non-striker on run-outs). |
| `bowler_wicket` | 1 if wicket credited to bowler (Caught, Bowled, LBW, Stump, Hit Wicket). Run-outs/retired/obstructing excluded. |
| `striker_dismissed` | 1 if the striker was dismissed (excl. Retire Out). |
| `nonstriker_dismissed` | 1 if the non-striker was dismissed (non-striker run-outs). |
| `cum_runs_before` | Team runs before this delivery. |
| `wkts_before` | Team wickets fallen before this delivery. |
| `wkts_in_hand` | 10 - wkts_before. |
| `legal_balls_before` | Legal balls bowled in innings before this delivery. |
| `innings_balls_limit` | Legal balls available in the innings (120, or revised balls if rain/DLS; revised_overs fields are in BALLS). |
| `balls_left` | innings_balls_limit - legal_balls_before (floored at 0). |
| `is_shortened` | 1 if innings_balls_limit < 120 (rain/DLS). Phase/par less meaningful - consider excluding. |
| `crr` | Current run rate (runs per over) before delivery; NaN at first ball. |
| `target` | Chase only: revised_target if given, else first-innings total + 1. NaN in innings 1. |
| `runs_needed` | Chase only: target - cum_runs_before. |
| `rrr` | Chase only: required run rate (runs per over) = runs_needed / balls_left * 6. Uncapped; NaN if balls_left == 0. |
| `rrr_minus_crr` | Chase only: rrr - crr. |
| `runs_needed_per_wkt_in_hand` | Chase only: runs_needed / wkts_in_hand. |
| `par_runs` | Innings 1 only: mean team score at the same legal-ball count in full-length innings of the same comp_group (all-out innings carried forward at final total). Descriptive benchmark, includes the match itself (negligible leakage). |
| `score_vs_par` | Innings 1 only: cum_runs_before - par_runs. |
| `proj_score_crr` | Innings 1 only: cum_runs_before + crr * balls_left / 6; NaN at first ball. |
| `match_complete` | 1 if both innings present AND result is a win/tie. RECOMMENDED DEFAULT FILTER for pressure work. |
| `has_chase_data` | 1 if the match has a second innings in the data. |
| `hs_innings_total` | HINDSIGHT. Final total of this innings. |
| `hs_first_inn_total` | HINDSIGHT. First innings final total of the match. |
| `hs_batting_team_won` | HINDSIGHT. 1/0 whether batting team won; NaN if no result. |
| `hs_margin_type` | HINDSIGHT. runs / wickets / tie / none (parsed from result text). |
| `hs_margin_value` | HINDSIGHT. Margin size. |
| `hs_chase_balls_left_at_end` | HINDSIGHT. Chase only: legal balls left when innings ended. |
| `hs_decided_super_over` | HINDSIGHT. 1 if the match went to a super over. |

## Other tables
- `match_innings_context.csv` - one row per match-innings (totals, target, limits, flags).
- `player_dim.csv` - one row per player ID (names, handedness, bowling type, teams, eligibility flags). **Always key on `player_id`.**
- `player_summary_batting.csv` / `player_summary_bowling.csv` - career totals 2022+ (overall, NOT pressure-specific) with `base_eligible_*` flags.
- `league_baselines_by_over.csv` / `league_baselines_by_phase.csv` - league-average batting/bowling rates by comp_group x innings x over/phase.
- `pipeline_manifest.json` - checksums, row counts, frozen config.

## Frozen conventions
- Legal ball = not wide and not no-ball. Full innings = 120 legal balls.
- Ball faced = anything but a wide. Bowler runs exclude byes/leg-byes/penalty.
- Bowler wicket = Caught, Bowled, LBW, Stump, Hit Wicket (no run-outs).
- Target = revised_target if present else first-innings total + 1. `*_revised_overs` fields in the raw data are in BALLS.
- Shared base eligibility: batters >= 300 balls faced AND >= 20 matches; bowlers >= 300 legal balls AND >= 20 matches. Pressure-sample minimums are set by each approach.