# Model 1 - v3 changes (ranking robustness)

Four changes were made **inside the model**. Where each lives: config values in `config.py`; ranking logic in `ranking.py`; pool step in `select_pool.py`; recency in `metrics.py` / `scoring.py` / `run_all.py`.

| # | Change | What it does | Where |
|---|---|---|---|
| 1 | **Pessimistic ranking** | Players are ordered by the **90th-percentile (worst-case) rank** across the 300 bootstrap draws, ties by median rank, then P(top N). A draw in which a player has no pressure exposure counts as the *worst* rank. Re-computed **inside the pool** being selected. | `ranking.robust_table`, `select_pool.py`, `RANK_Q` |
| 2 | **Tier penalty + Tier C list** | Points are subtracted from every bootstrap score *before* ranking: A 0, B 5, C 20 (`TIER_PENALTY`). Tier C players never enter the main top-N: they get their own watch-list (`TIER_C_MODE='separate'`; `'rank'` and `'drop'` also available). | `ranking.penalty / split_by_tier`, `config.py` |
| 3 | **Role gate** | Batter lists contain only batters + all-rounders; bowler lists only bowlers + all-rounders. Role is taken from a `role` column in the pool file (any spelling of batter / bowler / all-rounder), else `player_dim.csv`, else **inferred from usage** (bowler-capable = >= 180 legal balls bowled; batter-capable = >= 100 balls faced and median order <= 7). `pool_role_report.csv` shows the role used for every pool player and its source. | `ranking.resolve_roles / role_gate`, `select_pool.py` |
| 4 | **Recency weight** | Every ball / over / innings / match gets `w = 0.5 ** (age_days / 365)` from the latest match. Player means, shrinkage and effective sample size (Kish n) use `w`, so old evidence counts less *and* is shrunk harder. Optional hard cut `RECENCY_MIN_DATE` (e.g. `"2024-01-01"`) = "drop seasons before 2024" (those units get w = 0 and no longer count toward tiers). League expectations and pressure bands still use all matches. `RECENCY_HALF_LIFE_DAYS=None` and no cut reproduces v2 exactly. | `metrics.recency_weight / eb`, `scoring.py`, `run_all.py` |

## Why change 1 is built this way (finding from the data)
Two natural implementations of "rank by a lower bound" do **not** work on the stored v2 outputs:
* The stored `boot_rank_*` / `boot_P_top50_of_refpool` columns exist **only for Tier A** players. Thin players looked "dropped automatically" only because they had no interval at all.
* Ranking everyone by the 10th percentile of the bootstrap **score** *raises* thin players: shrinkage narrows their bootstrap spread, so Tier C ended up with 19 of the top 50 batters and 27 of the top 50 bowlers.
v3 therefore ranks by pessimistic **rank** with absent draws counted as worst, plus an explicit tier penalty applied inside each draw.

## Effect on the existing outputs (computed by `rerank.py` from the stored bootstrap; scores unchanged)
Top-50 in the full scored universe, v2 point-score list vs v3 robust list:
| | Tier C in top 50 | Tier A in top 50 | median pressure matches | last match before 2025 | overlap v2-v3 |
|---|---:|---:|---:|---:|---:|
| Batters v2 / v3 | 4 / 0 | 42 / 44 | 31 / 32 | 5 / 1 | 39 |
| Bowlers v2 / v3 | 7 / 0 | 28 / 33 | 18.5 / 20 | 11 / 7 | 41 |

Role gate on the full universe: 316 players leave the batter table's main ranking (bowlers), 112 leave the bowler table's (batters). v2's batter top 50 contained e.g. Rashid Khan, Mark Adair and Matthew Forde; they are now on the bowler side only.

## What was and was not re-run
* Changes **1-3** are applied to the existing outputs (`rankings_*_all.csv` carry the new columns: `player_role`, `list`, `tier_penalty`, `final_after_penalty`, `u_robust_rank`, `u_pool_rank_*`). They need only the stored bootstrap draws.
* Change **4** changes the *scores*, so it takes effect when `python run_all.py` is re-run on the data pack (`ball_features.csv.gz` was not in the supplied zip, so this could not be done here). Verified without the data: with weighting off the code reproduces v2 scores exactly (max difference 0.0 on a synthetic match set and on the estimator itself); with it on, the full components -> weights -> scores path runs and shifts scores sensibly. `run_all.py` also adds three sensitivity rows (no recency / drop pre-2024 / half-life 180 days) so the effect on the real data is reported automatically.
* The delivered `sensitivity.csv`, `validation_summary.json` and reliability figures are therefore still the v2 numbers.

## Judgement calls (all in `config.py`)
`RANK_Q = 0.90`, `TIER_PENALTY = {A:0, B:5, C:20}`, half-life 365 days, role thresholds. None is estimated from data; check them with the sensitivity rows after the re-run.
