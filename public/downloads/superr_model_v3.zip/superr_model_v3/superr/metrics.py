"""
Stage 2 - player performance under pressure.
 * every metric = RESIDUAL vs a league expectation for the same context cell (differences, never ratios)
 * residuals optionally venue-adjusted (leave-one-player-out venue effect, shrunk)
 * player residuals empirical-Bayes shrunk (prior strength estimated from the data; pooled WITHIN-player variance)
 * success measures judged vs the expected rate for the same innings / phase / start level
 * batters classified ball by ball on the pre-delivery state; bowlers by the state at the START of the over
"""
import numpy as np, pandas as pd
from config import CFG


def expected(df, value, fine, parent, k=50):
    g_f = df.groupby(fine)[value]; g_p = df.groupby(parent)[value]
    fm, fn = g_f.transform("mean"), g_f.transform("count")
    return (fn * fm + k * g_p.transform("mean")) / (fn + k)


def recency_weight(dates, cfg=CFG):
    """w = 0.5 ** (age / half-life) from the reference date (latest match); 0 before RECENCY_MIN_DATE.  None half-life -> all 1 (v2 behaviour)."""
    d = pd.to_datetime(dates)
    w = pd.Series(1.0, index=d.index if hasattr(d, "index") else None)
    hl = cfg.get("RECENCY_HALF_LIFE_DAYS")
    if hl:
        ref = pd.to_datetime(cfg.get("RECENCY_REF_DATE") or d.max())
        w = pd.Series(np.power(0.5, ((ref - d).dt.days.clip(lower=0)) / hl), index=d.index)
    if cfg.get("RECENCY_MIN_DATE"):
        w = w.where(d >= pd.to_datetime(cfg["RECENCY_MIN_DATE"]), 0.0)
    return w.values


def eb(units, pid, x, min_n=5, w="w_rec"):
    """Empirical-Bayes shrinkage of per-player mean residual (method of moments, pooled within-player variance).
    v3: if the units carry a recency-weight column `w`, player means are weighted and n is the Kish effective sample size (sum w)^2 / sum w^2
    (the exact precision of a weighted mean), so stale evidence counts less AND is shrunk harder.  The pooled within-player variance uses the
    unbiased weighted estimator.  With w == 1 everywhere this is exactly the v2 estimator.  min_n counts raw units with w > 0."""
    has_w = w in units.columns
    u = units[[pid, x, w]] if has_w else units[[pid, x]].assign(**{w: 1.0})
    u = u.dropna(subset=[x]); u = u[u[w] > 0]
    u = u.assign(_wx=u[w] * u[x], _w2=u[w] ** 2); g = u.groupby(pid)
    sw, sw2 = g[w].sum(), g._w2.sum()
    t = pd.DataFrame({"n": sw ** 2 / sw2, "n_raw": g.size(), "mean": g._wx.sum() / sw})
    u["_d2"] = u[w] * (u[x] - u[pid].map(t["mean"])) ** 2
    dof = (sw - sw2 / sw).clip(lower=0).sum()
    s2 = u._d2.sum() / max(dof, 1)
    q = t[t.n_raw >= min_n]; wq = q.n
    if len(q) < 5:
        t["shrunk"] = 0.0; t.attrs.update(k=1e6, tau=1e-6, s2=float(s2)); return t
    mu = np.average(q["mean"], weights=wq)
    tau2 = max(np.average((q["mean"] - mu) ** 2, weights=wq) - np.average(s2 / q.n, weights=wq), 1e-12)
    k = float(np.clip(s2 / tau2, 1, 1e6))
    t["shrunk"] = t["mean"] * t.n / (t.n + k)
    t.attrs.update(k=k, tau=float(np.sqrt(tau2)), s2=float(s2))
    return t


def eb_diff(up, ul, pid, x, min_n=5):
    """Shrunk (pressure - own usual) difference; noise of the difference uses BOTH sample sizes."""
    s2p, s2l = up[x].var(), ul[x].var()
    a = up.groupby(pid)[x].agg(n_p="size", m_p="mean"); b = ul.groupby(pid)[x].agg(n_l="size", m_l="mean")
    t = a.join(b, how="left"); t["delta"] = t.m_p - t.m_l; t["se"] = np.sqrt(s2p / t.n_p + s2l / t.n_l)
    noise = t.se ** 2
    q = t[(t.n_p >= min_n) & (t.n_l >= min_n)]
    if len(q) < 5:
        t["shrunk"] = 0.0; t.attrs["tau"] = 1e-6; return t
    wq = 1 / q.se ** 2
    tau2 = max(np.average((q.delta - np.average(q.delta, weights=wq)) ** 2, weights=wq) - np.mean(q.se ** 2), 1e-12)
    t["shrunk"] = np.where(t.n_l.fillna(0) >= min_n, t.delta * tau2 / (tau2 + noise), 0.0)
    t.attrs["tau"] = float(np.sqrt(tau2)); return t


def venue_adjust(u, pid, col, venue="venue_id", min_n=30):
    """Residual minus a shrunk venue effect estimated WITHOUT the player's own deliveries (no self-absorption)."""
    x = u[col]; s2 = x.var()
    gv = u.groupby(venue)[col].agg(S="sum", N="count"); t = gv.assign(m=gv.S / gv.N); q = t[t.N >= min_n]
    if len(q) < 5: return x
    mu = np.average(q.m, weights=q.N)
    tau2 = max(np.average((q.m - mu) ** 2, weights=q.N) - np.average(s2 / q.N, weights=q.N), 1e-12); kv = s2 / tau2
    Sv, Nv = u.groupby(venue)[col].transform("sum"), u.groupby(venue)[col].transform("count")
    Sp, Np = u.groupby([venue, pid])[col].transform("sum"), u.groupby([venue, pid])[col].transform("count")
    eff = ((Sv - Sp) - mu * (Nv - Np)) / (Nv - Np + kv)
    return x - eff.fillna(0)


# ------------------------------------------------------------------ batting
def batting_units(D, cfg=CFG, venue_resid=None):
    venue_resid = cfg["VENUE_RESID"] if venue_resid is None else venue_resid
    f = D[D.batter_faced == 1].copy()
    f["bnd"] = ((f.is_bat_four == 1) | (f.is_bat_six == 1)).astype(float)
    fine = ["comp_group", "innings", "overid", "band_bat", "bat_role_pos"]; parent = ["comp_group", "innings", "overid", "band_bat"]
    f["res_runs"] = f.bat_runs - expected(f, "bat_runs", fine, parent, cfg["EXPECT_K_BAT"])
    f["res_bnd"] = f.bnd - expected(f, "bnd", fine, parent, cfg["EXPECT_K_BAT"])
    nf = f[f.free_hit == 0].copy()                                                     # dismissal rates exclude free hits
    nf["res_dis"] = nf.striker_dismissed - expected(nf, "striker_dismissed", fine, parent, cfg["EXPECT_K_BAT"])
    f["res_dis"] = nf["res_dis"].reindex(f.index)
    f["res_runs_nv"] = f.res_runs
    f["w_rec"] = recency_weight(f.match_date, cfg)
    if venue_resid:
        f["res_runs"] = venue_adjust(f, "striker_id", "res_runs"); f["res_dis"] = venue_adjust(f, "striker_id", "res_dis")
    return f


def batting_innings(f, cfg=CFG):
    """One row per batter innings (>= RELIEF_MIN_BALLS balls, entering at serious/high pressure)."""
    g = f.groupby(["match_id", "innings", "striker_id"], sort=False)
    first, last = g.head(1).set_index(["match_id", "innings", "striker_id"]), g.tail(1).set_index(["match_id", "innings", "striker_id"])
    t = pd.DataFrame({"balls": g.size(), "entry_band": first.band_bat, "entry_r1": first.r1, "exit_r1": last.r1,
                      "comp_group": first.comp_group, "phase": first.phase, "match_date": first.match_date}).reset_index()
    t["w_rec"] = recency_weight(t.match_date, cfg)
    t = t[(t.balls >= cfg["RELIEF_MIN_BALLS"]) & (t.entry_band != "low")].copy()
    t["drop"] = t.entry_r1 - t.exit_r1                         # exit = pre-delivery state of the last ball faced (own dismissal excluded)
    t["success"] = (t["drop"] >= cfg["RELIEF_THR"]).astype(float)
    t["bin"] = (t.entry_r1 * 2).round() / 2
    t["p_exp"] = expected(t, "success", ["comp_group", "innings", "phase", "bin"], ["comp_group", "bin"], cfg["EXPECT_K_SUCC"])
    t["res_succ"] = t.success - t.p_exp
    return t.rename(columns={"striker_id": "pid"})


def batting_scores(f, inn):
    P = f[f.band_bat != "low"]; base = {}
    for band in ("serious", "high"):
        fb = P[P.band_bat == band]
        tabs = {"runs": eb(fb, "striker_id", "res_runs"), "dismissal": eb(fb, "striker_id", "res_dis"), "boundary": eb(fb, "striker_id", "res_bnd")}
        tabs["relief"] = eb(inn[inn.entry_band == band], "pid", "res_succ", min_n=3)
        base[band] = tabs
    return base


# ------------------------------------------------------------------ bowling
def bowling_overs(D, cfg=CFG, venue_resid=None):
    venue_resid = cfg["VENUE_RESID"] if venue_resid is None else venue_resid
    L = D.copy(); L["bnd_leg"] = (((L.is_bat_four == 1) | (L.is_bat_six == 1)) & (L.is_legal == 1)).astype(int)
    g = L.groupby(["match_id", "innings", "overid"], sort=False)
    o = g.agg(bowler_id=("bowler_id", "first"), n_bowl=("bowler_id", "nunique"), legal=("is_legal", "sum"), runs=("bowler_runs", "sum"),
              wkts=("bowler_wicket", "sum"), dots=("is_dot_bowler", "sum"), bnd=("bnd_leg", "sum"), start_tot=("press_bowl", "first"),
              start_band=("band_bowl", "first"), comp_group=("comp_group", "first"), match_date=("match_date", "first"),
              venue_id=("venue_id", "first")).reset_index()
    o = o[(o.n_bowl == 1) & (o.legal == 6)].copy()
    o["w_rec"] = recency_weight(o.match_date, cfg)
    o["phase"] = np.select([o.overid <= 6, o.overid <= 15], ["PP", "MID"], "DEATH")
    nxt = o[["match_id", "innings", "overid", "start_tot"]].copy(); nxt["overid"] -= 1
    o = o.merge(nxt.rename(columns={"start_tot": "end_tot"}), on=["match_id", "innings", "overid"], how="left")
    o["drop"] = o.start_tot - o.end_tot
    o["success"] = np.where(o.end_tot.notna(), (o["drop"] >= cfg["BOWL_SUCCESS_THR"]).astype(float), np.nan)
    fine = ["comp_group", "innings", "overid", "start_band"]; parent = ["comp_group", "innings", "overid"]
    for v in ("runs", "wkts", "dots", "bnd"):
        o["e_" + v] = expected(o, v, fine, parent, cfg["EXPECT_K_BOWL"])
    o["res_econ"] = o.e_runs - o.runs; o["res_wkt"] = o.wkts - o.e_wkts; o["res_dot"] = o.dots - o.e_dots; o["res_bnd"] = o.e_bnd - o.bnd
    if venue_resid:
        for c in ("res_econ", "res_dot", "res_wkt"): o[c] = venue_adjust(o, "bowler_id", c)
    ok = o.success.notna(); o["sbin"] = np.floor(o.start_tot).clip(3, 14)
    o.loc[ok, "p_exp"] = expected(o[ok], "success", ["comp_group", "innings", "phase", "sbin"], ["comp_group", "sbin"], cfg["EXPECT_K_SUCC"])
    o["res_succ"] = o.success - o.p_exp
    return o


def bowling_scores(O):
    P = O[O.start_band != "low"]; base = {}
    for band in ("serious", "high"):
        ob = P[P.start_band == band]
        base[band] = {"economy": eb(ob, "bowler_id", "res_econ"), "wicket": eb(ob, "bowler_id", "res_wkt"), "dot": eb(ob, "bowler_id", "res_dot"),
                      "boundary": eb(ob, "bowler_id", "res_bnd"), "success": eb(ob[ob.success.notna()], "bowler_id", "res_succ")}
    return base
