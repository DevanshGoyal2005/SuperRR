"""
Apply the v3 ranking (tier penalty, pessimistic bootstrap rank, role gate, Tier C watch-list) to EXISTING outputs, without re-fitting the model.

    python rerank.py            # reads outputs/rankings_*_all.csv + boot_scores_*.csv.gz, rewrites rankings_*_all.csv with the v3 columns

Use it when the scores are unchanged but the ranking rules in config.py (RANK_Q, TIER_PENALTY, TIER_C_MODE, ROLE_*) are.
Scores themselves (incl. the recency weight, change 4) only change when run_all.py is re-run on the data pack.
"""
import pandas as pd
from config import CFG
import ranking as RK

OUT = CFG["OUT_DIR"]
V3_COLS = ["player_role", "role_source", "role_ok", "list", "tier_penalty", "final_after_penalty"]


def main():
    dim = pd.read_csv(f"{CFG['SHARED_DIR']}/player_dim.csv")
    TB, TW = pd.read_csv(f"{OUT}/rankings_batters_all.csv"), pd.read_csv(f"{OUT}/rankings_bowlers_all.csv")
    drop = lambda T: T.drop(columns=[c for c in T.columns if c in V3_COLS or c.startswith("u_")])
    TB, TW = drop(TB), drop(TW)
    roles = RK.resolve_roles(TB, TW, dim.set_index("player_id")["role"] if "role" in dim.columns else None)
    for T, side, label in ((TB, "bat", "batters"), (TW, "bowl", "bowlers")):
        boot = pd.read_csv(f"{OUT}/boot_scores_{label}.csv.gz", index_col=0)
        R = RK.order(RK.annotate(T, boot, side, roles)); R.to_csv(f"{OUT}/rankings_{label}_all.csv", index=False)
        print(label, R.list.value_counts().to_dict())


if __name__ == "__main__":
    main()
