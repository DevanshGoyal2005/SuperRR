"""
SINGLE SOURCE OF TRUTH for every tunable number in the model.  Nothing else in the package hard-codes a threshold or weight.
Change a value here -> re-run `python run_all.py`; every output file is regenerated consistently.
"""
CFG = dict(
    # ---- paths (relative to this folder)
    SHARED_DIR="../shared_outputs", RAW_DIR="../Data Pack", OUT_DIR="./outputs",

    # ---- universe
    EVAL_GROUPS=["IPL", "T20I"],            # problem statement: IPL + T20I only (other T20 excluded)

    # ---- pressure definition
    WINDOW=12,                              # recent-ball window (legal balls) for wickets / runs
    Q_SERIOUS=0.60, Q_HIGH=0.85,            # empirical cut-offs on the 3..15 total (percentiles of the total)
    VENUE_PAR=True,                         # scale first-innings par path by shrunk venue factor

    # ---- performance layer
    VENUE_RESID=True,                       # leave-one-player-out venue adjustment of residuals
    EXPECT_K_BAT=50, EXPECT_K_BOWL=40, EXPECT_K_SUCC=30,      # shrink of fine context cell toward parent cell
    RELIEF_THR=1.0, RELIEF_MIN_BALLS=6,     # batter relief: drop of >= 1.0 in r1, innings of >= 6 balls
    BOWL_SUCCESS_THR=2.0,                   # bowler over success: drop of >= 2.0 in total pressure
    CONS_MIN_BALLS=6, CONS_MIN_OVERS=1,     # minimum exposure for a match to count as a consistency observation
    BAND_W={"high": 0.6, "serious": 0.4},   # serious/high mix inside the level score

    # ---- priors ("cricket importance"); final weight = prior x measured split-half reliability, renormalised
    PRIOR_BAT={"relief": 0.30, "runs": 0.45, "dismissal": 0.25},
    # over-success is DESCRIPTIVE ONLY: no detectable between-bowler signal (reliability ~0.19, EB k = 1e6 in high band,
    # not fixed by richer baselines).  run_all.py re-tests it every run and prints a warning if that changes.
    PRIOR_BOWL={"success": 0.0, "economy": 0.35, "wicket": 0.20, "dot": 0.15},
    PRIOR_FINAL={"level": 0.65, "resilience": 0.20, "consistency": 0.15},

    # ---- sample tiers (serious+high pressure exposure).  Tier A = reference pool for percentiles.
    TIER_A_BAT=(100, 15), TIER_B_BAT=(40, 6),            # (pressure balls, matches)
    TIER_A_BOWL=(25, 15), TIER_B_BOWL=(10, 6),           # (pressure overs, matches)
    PHASE_MIN_OVERS=12,                                  # pressure overs needed in a phase to be in that phase's reference pool

    # ---- roles (usage based; editable)
    TOP_ORDER_MAX=3, FINISHER_MIN_ORDER=5, FINISHER_MIN_DEATH_SHARE=0.30, SPECIALIST_MIN_SHARE=0.30,

    K_NOSIGNAL=1e5,                         # EB prior strength at/above this = no detectable between-player signal -> metric-band scores a neutral 50

    # ---- v3 change 4: RECENCY weight (current form).  Each unit (ball / over / innings / match) gets w = 0.5 ** (age_days / half-life),
    #      age measured from the latest match in the data.  Player means, shrinkage and effective sample sizes all use w.
    #      None disables weighting (reproduces v2 exactly).  RECENCY_MIN_DATE = hard cut: units before it get w = 0 and do not count
    #      toward tiers (e.g. "2024-01-01" = "drop seasons before 2024").  League expectations / pressure bands still use ALL matches.
    RECENCY_HALF_LIFE_DAYS=365, RECENCY_MIN_DATE=None, RECENCY_REF_DATE=None,      # ref date None -> latest match in the data

    # ---- v3 changes 1-3: robust ranking, tier penalty, role gate (see ranking.py)
    RANK_Q=0.90,                            # rank by the PESSIMISTIC end of the bootstrap rank interval (90th pct of rank; higher number = worse)
    TIER_PENALTY={"A": 0.0, "B": 5.0, "C": 20.0},   # points subtracted from every bootstrap score before ranking (scores are 0-100 percentiles); judgement
    TIER_C_MODE="separate",                 # 'separate' = Tier C never enters the main top-N, gets its own watch-list | 'rank' = ranked with the penalty | 'drop'
    ROLE_MIN_BOWL_BALLS=180,                # usage-based role fallback: >= 30 overs bowled (IPL+T20I) => bowler-capable
    ROLE_MIN_BAT_BALLS=100, ROLE_BAT_MAX_ORDER=7,   # >= 100 balls faced AND median order <= 7 => batter-capable

    # ---- validation / uncertainty
    N_BOOT=300, N_SPLITS=8, SEED=2027,
)
FULL_MEMBERS = {"India", "Australia", "England", "South Africa", "New Zealand", "Pakistan", "Sri Lanka",
                "Bangladesh", "West Indies", "Afghanistan", "Zimbabwe", "Ireland"}
