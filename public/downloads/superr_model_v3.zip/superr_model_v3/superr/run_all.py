"""
End-to-end run.   python run_all.py [--nboot N]      (needs ../shared_outputs from run_pipeline.py and the raw data pack for playing_eleven)
Writes everything to ./outputs.  Deterministic (fixed seed).
"""
import argparse, json, os, time, numpy as np, pandas as pd
import pressure as PR, metrics as M, scoring as S, reliab as R, validate as V, ranking as RK
from config import CFG

ap = argparse.ArgumentParser(); ap.add_argument("--nboot", type=int, default=CFG["N_BOOT"]); ap.add_argument("--nsplits", type=int, default=CFG["N_SPLITS"]); args = ap.parse_args()
OUT = CFG["OUT_DIR"]; os.makedirs(OUT, exist_ok=True); T0 = time.time()
log = lambda m: print(f"[{time.time()-T0:6.0f}s] {m}", flush=True)
norm = lambda d: {k: (v / sum(d.values()) if sum(d.values()) else 0.0) for k, v in d.items()}

# ------------------------------------------------------------------ 1. pressure + components
B = PR.load(); D, cuts, meta = PR.build_pressure(B); dim = pd.read_csv(f"{CFG['SHARED_DIR']}/player_dim.csv")
if CFG["RECENCY_HALF_LIFE_DAYS"] and not CFG["RECENCY_REF_DATE"]:                  # v3: fix the recency reference date ONCE (bootstrap / splits reuse it)
    CFG["RECENCY_REF_DATE"] = str(pd.to_datetime(D.match_date).max().date())
C = S.components(D); log(f"pressure + components built: {len(D):,} deliveries, {D.match_id.nunique()} matches")

# ------------------------------------------------------------------ 2. weights = prior x measured reliability (+ automatic no-signal gates)
rb, rw = R.reliabilities(C); WB = R.derive_weights(CFG["PRIOR_BAT"], rb); WW = R.derive_weights(CFG["PRIOR_BOWL"], rw)
succ_rel = rw["success"]; succ_k = {b: C["bowl_tabs"][b]["success"].attrs["k"] for b in ("serious", "high")}
if succ_rel >= 0.30 or min(succ_k.values()) < CFG["K_NOSIGNAL"] / 10:
    log(f"WARNING: bowler over-success now shows signal (reliability {succ_rel:.2f}, k {succ_k}) - revisit PRIOR_BOWL['success'] in config.py")
wsplit, wsplit_rows = V.whole_split(D, WB, WW, n_splits=args.nsplits); log("whole-score split-half done")
rc = R.consistency_reliability(C); rr = R.resilience_replication(C)
sig = lambda rho, n: rho if rho > 2 / np.sqrt(n) else 0.0
def final_w(side):
    pf = CFG["PRIOR_FINAL"]; r_level = float(wsplit.loc[side, "r_SB"])
    return norm({"level": pf["level"] * r_level, "resilience": pf["resilience"] * sig(*rr[side]), "consistency": pf["consistency"] * rc[side]})
FB, FW = final_w("bat"), final_w("bowl")
bat = S.combine(C, "bat", WB, final_w=FB); bowl = S.combine(C, "bowl", WW, final_w=FW)

# ------------------------------------------------------------------ 3. scorecards (ALL players with pressure data; tier = evidence quality)
bc, wc = S.player_context(D, dim); names = dim.set_index("player_id").display_name
ph = S.phase_profiles(C["O"], WW)
f, O, P, Pq, inn = C["f"], C["O"], C["P"], C["Pq"], C["inn"]
L_bat = f[f.band_bat == "low"]; L_bowl = O[O.start_band == "low"]

def bat_card():
    t = bat.copy(); idx = t.index
    t.insert(0, "player", names.reindex(idx).values); t.insert(1, "player_id", idx)
    t = t.join(bc.drop(columns=["matches_all"]).rename(columns={"balls_all": "balls_all_situations"})).join(C["bat_ex"].drop(columns="tier"))
    t["matches_all_situations"] = bc.matches_all.reindex(idx).values
    g = P.groupby("striker_id"); pooled = M.eb(P, "striker_id", "res_runs"); low = M.eb(L_bat, "striker_id", "res_runs"); rd = C["bat_res_tab"]
    t["pressure_strike_rate"] = (g.bat_runs.sum() / g.size() * 100).reindex(idx).round(1)
    t["runs_above_exp_per100_pressure"] = (pooled.shrunk.reindex(idx) * 100).round(1)
    t["runs_above_exp_per100_usual"] = (low.shrunk.reindex(idx) * 100).round(1)
    t["pressure_minus_usual_per100_raw"] = (rd.delta.reindex(idx) * 100).round(1); t["pressure_minus_usual_80pct_halfwidth"] = (1.28 * rd.se.reindex(idx) * 100).round(1)
    ii = inn.groupby("pid"); t["relief_rate_pct"] = (ii.success.mean() * 100).reindex(idx).round(1); t["relief_expected_pct"] = (ii.p_exp.mean() * 100).reindex(idx).round(1)
    t["sample_reliability_primary"] = (pooled.n / (pooled.n + pooled.attrs["k"])).reindex(idx).round(2)
    t["eligible_ref_pool"] = t.tier.eq("A"); return t

def bowl_card():
    t = bowl.copy(); idx = t.index
    t.insert(0, "player", names.reindex(idx).values); t.insert(1, "player_id", idx)
    t = t.join(wc.drop(columns=["matches_all"]).rename(columns={"legal_all": "legal_balls_all_situations"})).join(C["bowl_ex"].drop(columns="tier"))
    t["matches_all_situations"] = wc.matches_all.reindex(idx).values
    g = Pq.groupby("bowler_id"); pooled = M.eb(Pq, "bowler_id", "res_econ"); low = M.eb(L_bowl, "bowler_id", "res_econ"); rd = C["bowl_res_tab"]
    t["pressure_economy"] = (g.runs.sum() / g.legal.sum() * 6).reindex(idx).round(2); t["pressure_dot_pct"] = (g.dots.sum() / g.legal.sum() * 100).reindex(idx).round(1)
    t["runs_saved_per_over_pressure"] = pooled.shrunk.reindex(idx).round(2); t["runs_saved_per_over_usual"] = low.shrunk.reindex(idx).round(2)
    t["pressure_minus_usual_raw"] = rd.delta.reindex(idx).round(2); t["pressure_minus_usual_80pct_halfwidth"] = (1.28 * rd.se.reindex(idx)).round(2)
    t["over_success_pct_descriptive"] = (g.success.mean() * 100).reindex(idx).round(1); t["over_success_expected_pct"] = (g.p_exp.mean() * 100).reindex(idx).round(1)
    t["sample_reliability_primary"] = (pooled.n / (pooled.n + pooled.attrs["k"])).reindex(idx).round(2)
    for p in ph.values(): t = t.join(p)
    t["eligible_ref_pool"] = t.tier.eq("A"); return t

SB, SW = bat_card(), bowl_card()
for t in (SB, SW):
    t["rank_in_ref_pool"] = t.final.where(t.tier == "A").rank(ascending=False, method="first")

# ------------------------------------------------------------------ 4. bootstrap over matches (performance layer; pressure bands held fixed)
def boot_D(D, rng):
    g = D.groupby("match_id").indices; pick = rng.choice(np.array(list(g.keys())), size=len(g), replace=True); parts = []
    for c, m in enumerate(pick):
        s = D.iloc[g[m]].copy(); s["match_id"] = c; parts.append(s)
    return pd.concat(parts, ignore_index=True)
rng = np.random.default_rng(CFG["SEED"]); boots = {"bat": [], "bowl": []}
for b in range(args.nboot):
    Cb = S.components(boot_D(D, rng))
    boots["bat"].append(S.combine(Cb, "bat", WB, final_w=FB).final.rename(b)); boots["bowl"].append(S.combine(Cb, "bowl", WW, final_w=FW).final.rename(b))
    if (b + 1) % 25 == 0: log(f"bootstrap {b+1}/{args.nboot}")
BM = {s: pd.concat(v, axis=1) for s, v in boots.items() if v}
for s, t in (("bat", SB), ("bowl", SW)):
    if s in BM:
        M_ = BM[s].reindex(t.index); M_.index.name = "player_id"; M_.to_csv(f"{OUT}/boot_scores_{'batters' if s=='bat' else 'bowlers'}.csv.gz")
        A = t.index[t.tier == "A"]; rk = M_.loc[A].rank(ascending=False, method="first")
        t["boot_rank_p10"] = rk.quantile(.1, axis=1); t["boot_rank_median"] = rk.median(axis=1); t["boot_rank_p90"] = rk.quantile(.9, axis=1)
        t["boot_P_top20_of_refpool"] = (rk <= 20).mean(axis=1); t["boot_P_top50_of_refpool"] = (rk <= 50).mean(axis=1)

# ------------------------------------------------------------------ 5. sensitivity
log("sensitivity runs")
base = {"bat": SB[SB.tier == "A"].final, "bowl": SW[SW.tier == "A"].final}
sens = []
def rec(name, Cv, wb=WB, ww=WW, fb=FB, fw=FW, band_w=None):
    row = {"variant": name}
    for side, w, fwv in (("bat", wb, fb), ("bowl", ww, fw)):
        t = S.combine(Cv, side, w, band_w=band_w, final_w=fwv); a = t[t.tier == "A"].final
        for k, v in V.compare(base[side], a).items(): row[f"{side}_{k}"] = v
    sens.append(row)
rec("no venue adjustment of residuals", S.components(D, venue_resid=False))
D_nv, _, _ = PR.build_pressure(B, venue_par=False); rec("no venue factor in par path (and no residual venue adj.)", S.components(D_nv, venue_resid=False))
D2, _, _ = PR.build_pressure(B, window=18, q_serious=0.70, q_high=0.90); rec("cut-offs 70/90 + 18-ball window", S.components(D2))
D3, _, _ = PR.build_pressure(B, q_serious=0.50, q_high=0.80); rec("cut-offs 50/80", S.components(D3))
for thr, bthr in ((0.7, 1.5), (1.3, 2.5)):
    cv = dict(CFG, RELIEF_THR=thr, BOWL_SUCCESS_THR=bthr); rec(f"success thresholds {thr}/{bthr}", S.components(D, cv), band_w=None)
rec("predefined weights (prior only, no reliability adjustment)", C, wb=norm(CFG["PRIOR_BAT"]), ww=norm(CFG["PRIOR_BOWL"]))
rec("level score only (no consistency / resilience)", C, fb=dict(level=1, resilience=0, consistency=0), fw=dict(level=1, resilience=0, consistency=0))
for hw in (0.5, 0.7): rec(f"serious/high mix {int((1-hw)*100)}/{int(hw*100)}", C, band_w=dict(high=hw, serious=1 - hw))
rec("excluding T20Is vs associate-nation opponents", S.components(D[~V.assoc_mask(D)]))
Dipl = D[D.comp_group == "IPL"]; rec("IPL data only", S.components(Dipl, elig_scale=0.5))
rec("no recency weighting (v2 behaviour)", S.components(D, dict(CFG, RECENCY_HALF_LIFE_DAYS=None, RECENCY_MIN_DATE=None)))
rec("recency: drop seasons before 2024 (no decay)", S.components(D, dict(CFG, RECENCY_HALF_LIFE_DAYS=None, RECENCY_MIN_DATE="2024-01-01")))
rec("recency half-life 180 days", S.components(D, dict(CFG, RECENCY_HALF_LIFE_DAYS=180)))
SENS = pd.DataFrame(sens)

# ------------------------------------------------------------------ 6. evidence tables + write
fb_ = D[D.batter_faced == 1]
band_bat = fb_.groupby("band_bat").agg(balls=("bat_runs", "size"), SR=("bat_runs", lambda s: s.mean() * 100), dismissals_per100=("striker_dismissed", lambda s: s.mean() * 100),
        dot_pct=("is_dot_batter", lambda s: s.mean() * 100), batting_team_win_pct=("hs_batting_team_won", lambda s: s.mean() * 100)).loc[["low", "serious", "high"]].round(1)
band_bat["chasing_team_win_pct"] = fb_[fb_.innings == 2].groupby("band_bat").hs_batting_team_won.mean().mul(100).round(1).reindex(["low", "serious", "high"]).values
lg = D[D.is_legal == 1]
band_bowl = lg.groupby("band_bowl").agg(balls=("bowler_runs", "size"), economy=("bowler_runs", lambda s: s.mean() * 6), dot_pct=("is_dot_bowler", lambda s: s.mean() * 100),
        wkts_per100=("bowler_wicket", lambda s: s.mean() * 100), batting_team_win_pct=("hs_batting_team_won", lambda s: s.mean() * 100)).loc[["low", "serious", "high"]].round(2)
share = {c: dict(below5=float((D[c] < 5).mean()), mid_5_10=float(((D[c] >= 5) & (D[c] < 10)).mean()), ge10=float((D[c] >= 10).mean())) for c in ("press_bat", "press_bowl")}
corr = {"bat_components": D[["r1", "r2", "r3"]].corr().round(2).values.tolist(), "bowl_components": D[["q1", "q2", "q3"]].corr().round(2).values.tolist()}
metric_corr = {f"{s}_{b}": C[f"{s}_pct"][b][C[f"{s}_pool"]].corr(method="spearman").round(2).to_dict() for s in ("bat", "bowl") for b in ("serious", "high")}
with open(f"{OUT}/pressure_band_evidence.txt", "w") as fh:
    fh.write("BATTING bands (hindsight win% used for validation only)\n" + band_bat.to_string() + "\n\nBOWLING bands\n" + band_bowl.to_string() + "\n")
SENS.to_csv(f"{OUT}/sensitivity.csv", index=False); wsplit_rows.to_csv(f"{OUT}/whole_score_split_half_by_split.csv", index=False)
roles = RK.resolve_roles(SB, SW, dim.set_index("player_id")["role"] if "role" in dim.columns else None)       # explicit role field if the data pack provides one
SB = RK.order(RK.annotate(SB, BM["bat"], "bat", roles)); SW = RK.order(RK.annotate(SW, BM["bowl"], "bowl", roles))
cols_front_b = ["player", "player_id", "tier", "eligible_ref_pool", "rank_in_ref_pool", "final", "level", "level_serious", "level_high", "consistency", "resilience_pct"]
SB.to_csv(f"{OUT}/rankings_batters_all.csv", index=False)       # v3: ordered by list (main -> watch-list -> excluded), then pessimistic rank
SW.to_csv(f"{OUT}/rankings_bowlers_all.csv", index=False)
summ = dict(
    n_deliveries=len(D), n_matches=int(D.match_id.nunique()), cutoffs={k: [round(x, 2) for x in v] for k, v in cuts.items()}, venue_meta=meta,
    fixed_5_10_cutoff_shares=share, component_correlations=corr,
    tiers={"batters": SB.tier.value_counts().to_dict(), "bowlers": SW.tier.value_counts().to_dict()},
    reliability_batting_metrics={k: round(v, 2) for k, v in rb.items()}, reliability_bowling_metrics={k: round(v, 2) for k, v in rw.items()},
    weights_batting={k: round(v, 3) for k, v in WB.items()}, weights_bowling={k: round(v, 3) for k, v in WW.items()},
    whole_score_split_half=wsplit.to_dict("index"), consistency_reliability={k: round(v, 2) for k, v in rc.items()},
    resilience_replication_rho_n={k: (round(v[0], 3), v[1]) for k, v in rr.items()},
    final_weights_batting={k: round(v, 3) for k, v in FB.items()}, final_weights_bowling={k: round(v, 3) for k, v in FW.items()},
    eb_k_bat={k: round(v, 1) for k, v in C["bat_k"].items()}, eb_k_bowl={k: round(v, 1) for k, v in C["bowl_k"].items()},
    metric_score_correlations=metric_corr, n_boot=args.nboot, n_splits=args.nsplits, config=CFG)
json.dump(summ, open(f"{OUT}/validation_summary.json", "w"), indent=1, default=str)
log("done"); print(json.dumps({k: summ[k] for k in ("tiers", "reliability_batting_metrics", "reliability_bowling_metrics", "weights_batting", "weights_bowling", "whole_score_split_half", "consistency_reliability", "resilience_replication_rho_n", "final_weights_batting", "final_weights_bowling")}, indent=1))
print(SENS.to_string())
