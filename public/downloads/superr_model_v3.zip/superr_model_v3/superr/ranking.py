"""
Stage 5 - ROBUST RANKING (v3).  Turns scores + bootstrap draws into an ordering that does not reward thin samples.

 1. Tier penalty      : points subtracted from every bootstrap draw's score BEFORE ranking (CFG TIER_PENALTY).
 2. Pessimistic rank  : players are ordered by the PESSIMISTIC end (RANK_Q, default 90th percentile) of their rank distribution across
                        bootstrap draws, ties by median rank, then by P(top N).  A draw in which the player has no pressure exposure
                        counts as the WORST rank (absence is not neutral).
 3. Role gate         : batter lists contain only batters / all-rounders, bowler lists only bowlers / all-rounders
                        (role from the pool file or player_dim when supplied, otherwise inferred from usage - see infer_roles).
 4. Tier C handling   : TIER_C_MODE = 'separate' (own watch-list, default) | 'rank' (ranked with the penalty) | 'drop'.

Used by select_pool.py (ranking INSIDE a pool) and rerank.py (whole-universe tables).  Nothing here re-fits the model.
"""
import numpy as np, pandas as pd
from config import CFG

ROLE_BATTER, ROLE_BOWLER, ROLE_AR, ROLE_UNK = "batter", "bowler", "all-rounder", "unknown"


# ------------------------------------------------------------------ roles
def normalise_role(x):
    """Free-text role (any spelling the data pack / auction sheet uses) -> batter | bowler | all-rounder | unknown."""
    if x is None or (isinstance(x, float) and np.isnan(x)): return ROLE_UNK
    s = str(x).strip().lower().replace("_", "-").replace(" ", "-")
    if not s or s in ("nan", "none"): return ROLE_UNK
    if "all" in s and ("round" in s or s.startswith("ar") or s in ("all", "allrounder")): return ROLE_AR
    if s in ("ar", "a-r"): return ROLE_AR
    if "bowl" in s: return ROLE_BOWLER
    if "bat" in s or "wk" in s or "keeper" in s or "wicket" in s: return ROLE_BATTER
    return ROLE_UNK


def infer_roles(bat, bowl, cfg=CFG):
    """Usage-based role for every scored player (fallback when no explicit role field exists).
    bowler-flag : >= ROLE_MIN_BOWL_BALLS legal balls bowled (all situations, IPL+T20I 2022+)
    batter-flag : >= ROLE_MIN_BAT_BALLS balls faced AND median batting order <= ROLE_BAT_MAX_ORDER   (tail-enders who face balls do not count)
    both -> all-rounder; neither -> whichever table the player appears in (batting order decides if both)."""
    b = bat.set_index("player_id"); w = bowl.set_index("player_id")
    ids = b.index.union(w.index)
    balls = b.balls_all_situations.reindex(ids).fillna(0); order = b.median_order.reindex(ids)
    legal = w.legal_balls_all_situations.reindex(ids).fillna(0)
    is_bowl = legal >= cfg["ROLE_MIN_BOWL_BALLS"]
    is_bat = (balls >= cfg["ROLE_MIN_BAT_BALLS"]) & (order <= cfg["ROLE_BAT_MAX_ORDER"])
    role = pd.Series(ROLE_UNK, index=ids)
    role[is_bat & ~is_bowl] = ROLE_BATTER; role[is_bowl & ~is_bat] = ROLE_BOWLER; role[is_bat & is_bowl] = ROLE_AR
    rest = ~(is_bat | is_bowl)
    in_b, in_w = ids.isin(b.index), ids.isin(w.index)
    role[rest & in_b & ~in_w] = ROLE_BATTER; role[rest & in_w & ~in_b] = ROLE_BOWLER
    both = rest & in_b & in_w
    role[both & (order.fillna(11) <= cfg["ROLE_BAT_MAX_ORDER"])] = ROLE_BATTER; role[both & (order.fillna(11) > cfg["ROLE_BAT_MAX_ORDER"])] = ROLE_BOWLER
    return role.rename("role_inferred")


def resolve_roles(bat, bowl, explicit=None, cfg=CFG):
    """explicit: Series player_id -> free-text role (pool file / player_dim); explicit values win, usage inference fills the rest."""
    inf = infer_roles(bat, bowl, cfg); out = pd.DataFrame({"role_inferred": inf})
    out["role_given"] = ROLE_UNK
    if explicit is not None and len(explicit):
        out["role_given"] = explicit.map(normalise_role).reindex(out.index).fillna(ROLE_UNK)
    out["player_role"] = np.where(out.role_given != ROLE_UNK, out.role_given, out.role_inferred)
    out["role_source"] = np.where(out.role_given != ROLE_UNK, "given", "inferred from usage")
    return out


def role_gate(ids, roles, side):
    """Keep only ids allowed on this side's list.  All-rounders are allowed on both; 'unknown' is kept (and flagged) rather than silently lost."""
    r = roles.player_role.reindex(ids).fillna(ROLE_UNK)
    ok = {"bat": {ROLE_BATTER, ROLE_AR, ROLE_UNK}, "bowl": {ROLE_BOWLER, ROLE_AR, ROLE_UNK}}[side]
    return [i for i, x in zip(ids, r) if x in ok]


# ------------------------------------------------------------------ penalty + pessimistic ranking
def penalty(tier, cfg=CFG):
    return tier.map(cfg["TIER_PENALTY"]).astype(float).fillna(max(cfg["TIER_PENALTY"].values()))


def rank_draws(boot, tier, ids, cfg=CFG):
    """Per-draw rank (1 = best) of `ids` INSIDE that set, after the tier penalty.  A missing draw (no exposure) ranks last."""
    B = boot.reindex(ids).sub(penalty(tier.reindex(ids), cfg), axis=0)
    worst = len(ids) + 1
    rk = B.rank(ascending=False, method="average").fillna(worst)     # ties share a rank: result must not depend on row order
    return rk, B


def robust_table(boot, tier, ids, N, cfg=CFG):
    """Pessimistic-rank table for `ids` as a pool.  Sort key: pessimistic rank, then median rank, then -P(top N)."""
    rk, B = rank_draws(boot, tier, ids, cfg)
    t = pd.DataFrame({"pool_rank_best": rk.quantile(1 - cfg["RANK_Q"], axis=1), "pool_rank_median": rk.median(axis=1),
                      "pool_rank_pessimistic": rk.quantile(cfg["RANK_Q"], axis=1), f"P_top{N}_in_pool": (rk <= N).mean(axis=1),
                      "score_after_penalty_p10": B.quantile(.1, axis=1), "draws_with_exposure": boot.reindex(ids).notna().mean(axis=1)})
    t["tier_penalty"] = penalty(tier.reindex(ids), cfg).values
    t = t.sort_index().sort_values(["pool_rank_pessimistic", "pool_rank_median", f"P_top{N}_in_pool"], ascending=[True, True, False], kind="mergesort")
    t["robust_rank"] = np.arange(1, len(t) + 1)
    return t.round(2)


def split_by_tier(table, cfg=CFG):
    """-> (main, watchlist).  TIER_C_MODE: separate | rank | drop."""
    mode = cfg["TIER_C_MODE"]
    if mode == "rank": return table, table.iloc[0:0]
    main, c = table[table.tier != "C"], table[table.tier == "C"]
    return main, (c if mode == "separate" else c.iloc[0:0])


# ------------------------------------------------------------------ whole-universe annotation (used by run_all.py and rerank.py)
def annotate(T, boot, side, roles, N=50, cfg=CFG):
    """Add v3 columns to a rankings table (index or column `player_id`): role + gate, tier penalty, pessimistic rank, list assignment.
    list = 'main' (role-eligible, not Tier C) | 'watchlist' (role-eligible Tier C, TIER_C_MODE=separate) | 'excluded: role' | 'excluded: tier C'.
    Ranks are computed INSIDE each list over the role-eligible players, so the whole table is a ready-made pool of 'everyone'."""
    T = T.copy(); T = T.set_index("player_id", drop=False) if "player_id" in T.columns else T
    T["player_role"] = roles.player_role.reindex(T.index).fillna(ROLE_UNK).values; T["role_source"] = roles.role_source.reindex(T.index).values
    elig = role_gate(list(T.index), roles, side); T["role_ok"] = T.index.isin(elig)
    lst = pd.Series("excluded: role", index=T.index)
    ok = T[T.role_ok]; main, watch = split_by_tier(ok, cfg)
    lst[main.index] = "main"; lst[watch.index] = "watchlist"
    if cfg["TIER_C_MODE"] == "drop": lst[ok[ok.tier == "C"].index] = "excluded: tier C"
    T["list"] = lst.values
    T["tier_penalty"] = penalty(T.tier, cfg).values; T["final_after_penalty"] = (T.final - T.tier_penalty).round(2)
    for name, grp in (("main", main), ("watchlist", watch)):
        if len(grp):
            rt = robust_table(boot, T.tier, list(grp.index), N, cfg).add_prefix("u_")
            for c in rt.columns: T.loc[rt.index, c] = rt[c]
    return T


def order(T):
    """main by robust rank, then watch-list by its own rank, then the excluded."""
    key = T.list.map({"main": 0, "watchlist": 1}).fillna(2)
    return T.assign(_k=key).sort_values(["_k", "u_robust_rank", "final"], ascending=[True, True, False]).drop(columns="_k")
