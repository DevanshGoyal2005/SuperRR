"""Stage 4 - whole-score reliability (random match splits) and sensitivity analysis."""
import numpy as np, pandas as pd, scoring as S
from config import CFG, FULL_MEMBERS


def whole_split(D, w_bat, w_bowl, cfg=CFG, n_splits=None, seed=None):
    """Rebuild the whole performance layer on two random halves of the league's matches; compare level scores."""
    n_splits = n_splits or cfg["N_SPLITS"]; mids = D.match_id.unique(); rows = []
    for s in range(n_splits):
        rng = np.random.default_rng((seed or cfg["SEED"]) + s); perm = rng.permutation(mids); h = len(perm) // 2
        Ch = [S.components(D[D.match_id.isin(set(perm[:h]))], cfg, elig_scale=0.5), S.components(D[D.match_id.isin(set(perm[h:]))], cfg, elig_scale=0.5)]
        for side, w in (("bat", w_bat), ("bowl", w_bowl)):
            a, b = (S.combine(c, side, w, cfg=cfg) for c in Ch)
            a, b = a[a.tier == "A"].level, b[b.tier == "A"].level
            j = pd.concat([a, b], axis=1, keys=["a", "b"]).dropna(); r = j.a.corr(j.b, method="spearman")
            rows.append(dict(side=side, split=s, n=len(j), r_half=r, r_SB=max(2 * r / (1 + r), 0),
                             top10=len(set(j.a.nlargest(10).index) & set(j.b.nlargest(10).index)),
                             top20=len(set(j.a.nlargest(20).index) & set(j.b.nlargest(20).index)),
                             top50=len(set(j.a.nlargest(50).index) & set(j.b.nlargest(50).index)),
                             chance10=10 * 10 / len(j), chance20=20 * 20 / len(j), chance50=50 * 50 / len(j)))
    R = pd.DataFrame(rows)
    return R.groupby("side").mean(numeric_only=True).drop(columns="split").round(3), R


def compare(base, alt, ns=(10, 20, 50)):
    """Overlap of top-N and Spearman between two score Series (tier-A players present in both)."""
    j = pd.concat([base, alt], axis=1, keys=["b", "a"]).dropna()
    out = {f"top{n}": len(set(j.b.nlargest(n).index) & set(j.a.nlargest(n).index)) for n in ns}
    out["rho"] = round(float(j.b.corr(j.a, method="spearman")), 3); out["n_common"] = len(j); return out


def assoc_mask(D):
    return (D.comp_group == "T20I") & ~(D.batting_team.isin(FULL_MEMBERS) & D.bowling_team.isin(FULL_MEMBERS))
