"""Split-half reliability helpers (each player's matches split alternately in chronological order)."""
import numpy as np, pandas as pd


def half_assign(u, pid, mc="match_id", date="match_date"):
    mo = u.groupby([pid, mc])[date].first().reset_index()
    mo["rk"] = mo.groupby(pid)[date].rank(method="first"); mo["half"] = (mo.rk % 2).astype(int)
    return u.merge(mo[[pid, mc, "half"]], on=[pid, mc], how="left")


def sb_corr(u, pid, col, pool, stat="mean"):
    u = half_assign(u[u[pid].isin(pool[pool].index)], pid)
    a = u[u.half == 0].groupby(pid)[col].agg(stat); b = u[u.half == 1].groupby(pid)[col].agg(stat)
    j = pd.concat([a, b], axis=1, keys=["a", "b"]).dropna()
    r = j.a.corr(j.b, method="spearman")
    return float(max(2 * r / (1 + r), 0.0)) if pd.notna(r) else 0.0


def reliabilities(C):
    P, Pq, bp, wp = C["P"], C["Pq"], C["bat_pool"], C["bowl_pool"]
    Pp = P.assign(neg_dis=-P.res_dis); inn = C["inn"].rename(columns={"pid": "striker_id"})
    rb = dict(relief=sb_corr(inn, "striker_id", "res_succ", bp), runs=sb_corr(Pp, "striker_id", "res_runs", bp),
              dismissal=sb_corr(Pp, "striker_id", "neg_dis", bp), boundary=sb_corr(Pp, "striker_id", "res_bnd", bp))
    rw = dict(success=sb_corr(Pq[Pq.success.notna()], "bowler_id", "res_succ", wp), economy=sb_corr(Pq, "bowler_id", "res_econ", wp),
              wicket=sb_corr(Pq, "bowler_id", "res_wkt", wp), dot=sb_corr(Pq, "bowler_id", "res_dot", wp), boundary=sb_corr(Pq, "bowler_id", "res_bnd", wp))
    return rb, rw


def consistency_reliability(C):
    return dict(bat=sb_corr(C["cons_units_bat"], "striker_id", "hit", C["bat_pool"]), bowl=sb_corr(C["cons_units_bowl"], "bowler_id", "hit", C["bowl_pool"]))


def resilience_replication(C):
    """Does 'pressure minus own usual' replicate across halves of a player's matches?  (rho, n)"""
    out = {}
    for side, up, ul, pid, x, pool in (("bat", C["P"], C["f"][C["f"].band_bat == "low"], "striker_id", "res_runs", C["bat_pool"]),
                                       ("bowl", C["Pq"], C["O"][C["O"].start_band == "low"], "bowler_id", "res_econ", C["bowl_pool"])):
        a, b = half_assign(up[up[pid].isin(pool[pool].index)], pid), half_assign(ul[ul[pid].isin(pool[pool].index)], pid)
        d = {h: a[a.half == h].groupby(pid)[x].mean() - b[b.half == h].groupby(pid)[x].mean() for h in (0, 1)}
        j = pd.concat(d, axis=1).dropna(); out[side] = (float(j[0].corr(j[1], method="spearman")), int(len(j)))
    return out


def derive_weights(prior, rel):
    raw = {m: prior[m] * rel.get(m, 0.0) for m in prior}; s = sum(raw.values())
    return {m: (v / s if s > 0 else 0.0) for m, v in raw.items()}
