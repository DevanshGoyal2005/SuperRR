"""
Stage 1 - delivery-level PRESSURE identification (independent of player performance).
Batting  = r1 (behind par path) + r2 (wickets lost vs over norm) + r3 (recent wicket cluster)         -> 3..15
Bowling  = q1 (batting side ahead of path) + q2 (wickets in hand vs over norm) + q3 (recent runs)    -> 3..15
Percentiles are always taken inside (comp_group, innings, over).  No player identity is used anywhere here.
"""
import numpy as np, pandas as pd
from config import CFG


def load(path=None, cfg=CFG):
    B = pd.read_csv(path or f"{cfg['SHARED_DIR']}/ball_features.csv.gz")
    B = B[B.comp_group.isin(cfg["EVAL_GROUPS"]) & (B.match_complete == 1) & (B.is_shortened == 0)].copy()
    return B.sort_values(["match_id", "innings", "innings_ball_num"]).reset_index(drop=True)


def par_tables(B):
    i1 = B[B.innings == 1]
    path = i1.groupby(["comp_group", "legal_balls_before"]).par_runs.first().unstack(0)
    tot = i1.drop_duplicates("match_id").groupby("comp_group").hs_innings_total.mean()
    return path, tot


def venue_factors(B):
    """Shrunk ratio of a venue's mean first-innings total to its competition-group mean (method-of-moments shrinkage)."""
    i1 = B[B.innings == 1].drop_duplicates("match_id")[["match_id", "comp_group", "venue_id", "hs_innings_total"]].copy()
    i1["ratio"] = i1.hs_innings_total / i1.groupby("comp_group").hs_innings_total.transform("mean")
    t = i1.groupby("venue_id").ratio.agg(n="size", mean="mean"); q = t[t.n >= 3]
    s2 = i1.ratio.var(); mu = np.average(q["mean"], weights=q.n)
    tau2 = max(np.average((q["mean"] - mu) ** 2, weights=q.n) - np.average(s2 / q.n, weights=q.n), 1e-6)
    k = s2 / tau2
    return (1 + (t["mean"] - 1) * t.n / (t.n + k)), k


def free_hit_state(B):
    """Free hit = next delivery after a no-ball; it PERSISTS through wides (and a further no-ball) until a legal ball is bowled."""
    keys = [B.match_id, B.innings]
    mk = pd.Series(np.where(B.is_noball == 1, 1.0, np.where(B.is_legal == 1, 0.0, np.nan)), index=B.index)
    return mk.groupby(keys).ffill().groupby(keys).shift(1).fillna(0).astype(int)


def recent_window(B, window):
    rr = np.zeros(len(B)); rw = np.zeros(len(B))
    cr, wk, lb = B.cum_runs_before.values, B.wkts_before.values, B.legal_balls_before.values
    for _, idx in B.groupby(["match_id", "innings"], sort=False).indices.items():
        L, C_, W_ = lb[idx], cr[idx], wk[idx]
        j = np.searchsorted(L, np.maximum(L - window, 0), side="left")
        rr[idx] = C_ - C_[j]; rw[idx] = W_ - W_[j]
    return rr, rw


def pct_in_cell(B, col, ascending=True, cell=("comp_group", "innings", "overid")):
    s = B[col] if ascending else -B[col]
    return s.groupby([B[c] for c in cell]).rank(pct=True, method="average")


def build_pressure(B, cfg=CFG, window=None, q_serious=None, q_high=None, venue_par=None):
    window = window or cfg["WINDOW"]; q_serious = q_serious or cfg["Q_SERIOUS"]; q_high = q_high or cfg["Q_HIGH"]
    venue_par = cfg["VENUE_PAR"] if venue_par is None else venue_par
    B = B.copy(); meta = {}
    path, tot = par_tables(B)
    P = np.array([path.at[min(l, 119), g] for l, g in zip(B.legal_balls_before.values, B.comp_group.values)])
    if venue_par:
        fac, k = venue_factors(B); meta["venue_factor_k"] = float(k)
        fv = B.venue_id.map(fac).fillna(1.0).values
        P = np.where(B.innings.values == 1, P * fv, P)                           # chases already carry the venue via the target
        meta["venue_factor_range"] = (float(fac.min()), float(fac.max()))
    T = np.where(B.innings == 1, tot.reindex(B.comp_group).values, B.target.values)
    scale = T / tot.reindex(B.comp_group).values
    B["path_gap"] = P * scale - B.cum_runs_before          # > 0  => batting side BEHIND its path
    B["runs_last_w"], B["wkts_last_w"] = recent_window(B, window)

    B["p_gap"] = pct_in_cell(B, "path_gap"); B["p_wl"] = pct_in_cell(B, "wkts_before")
    B["r1"] = 1 + 4 * B.p_gap; B["r2"] = 1 + 4 * B.p_wl
    B["r3"] = B.wkts_last_w.clip(upper=3).map({0: 1.0, 1: 3.0, 2: 4.0, 3: 5.0})
    B["press_bat"] = B.r1 + B.r2 + B.r3

    B["p_ahead"] = pct_in_cell(B, "path_gap", ascending=False); B["p_inhand"] = pct_in_cell(B, "wkts_in_hand"); B["p_mom"] = pct_in_cell(B, "runs_last_w")
    B["q1"] = 1 + 4 * B.p_ahead; B["q2"] = 1 + 4 * B.p_inhand; B["q3"] = 1 + 4 * B.p_mom
    B["press_bowl"] = B.q1 + B.q2 + B.q3

    cuts = {}
    for name, side in (("press_bat", "bat"), ("press_bowl", "bowl")):
        cs, ch = B[name].quantile([q_serious, q_high]).values; cuts[name] = (float(cs), float(ch))
        B["band_" + side] = np.select([B[name] >= ch, B[name] >= cs], ["high", "serious"], "low")
    B["free_hit"] = free_hit_state(B)
    B["bat_role_pos"] = pd.cut(B.batting_order, [0, 3, 5, 11], labels=["top", "middle", "lower"]).astype(str)
    return B, cuts, meta
