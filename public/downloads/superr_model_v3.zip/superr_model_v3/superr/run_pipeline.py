#!/usr/bin/env python3
"""
SupeRR Selector S2 - Round 1 - SHARED DATA PIPELINE
===================================================
Turns the raw Data Pack into frozen, analysis-ready tables that BOTH approaches
(A: Pressure Index, B: Leverage model) build on. Nothing in here defines
"pressure" - that is deliberately left to each approach.

Usage
-----
    python run_pipeline.py --zip data_pack.zip --out ./shared_outputs
    python run_pipeline.py --data-dir "./Data Pack" --out ./shared_outputs

Deterministic: same input -> same output (checksums in pipeline_manifest.json).
"""
import argparse, hashlib, json, re, sys, zipfile, tempfile
from pathlib import Path
import numpy as np
import pandas as pd

PIPELINE_VERSION = "1.0.0"

# ----------------------------------------------------------------------------
# FROZEN CONFIG  (change = new pipeline version; tell both approach chats)
# ----------------------------------------------------------------------------
CFG = dict(
    T20_BALLS=120,
    PHASE_OVERS={"PP": (1, 6), "MID": (7, 15), "DEATH": (16, 20)},
    BOWLER_WICKET_TYPES=["Caught", "Bowled", "LBW", "Stump", "Hit Wicket"],
    # shared BASE eligibility (approach-specific pressure-sample cuts come later)
    ELIG_BAT_MIN_BALLS=300, ELIG_BAT_MIN_MATCHES=20,
    ELIG_BOWL_MIN_BALLS=300, ELIG_BOWL_MIN_MATCHES=20,
    ACTIVE_SINCE="2025-01-01",
    PAR_MIN_INNINGS=30,
)

RAW_FILES = ["ball_by_ball", "matches", "competitions", "teams",
             "competition_team_player_mapping", "playing_eleven"]

# ----------------------------------------------------------------------------
# Column documentation = single source of truth for DATA_DICTIONARY.md
# ----------------------------------------------------------------------------
BALL_COLS = {
 # identity / match context
 "match_id": "Match key (matches.csv).",
 "comp_id": "Competition key.",
 "comp_name": "Competition name.",
 "comp_group": "IPL / T20I / OTHER_T20 (Emerging Teams Asia Cup 2024, Asia Cup Rising Stars 2025). Use for IPL-vs-T20I handling.",
 "season_year": "Calendar year of match_date.",
 "match_date": "Match date (YYYY-MM-DD).",
 "stage": "Stage text from matches.csv (League, Final, ...).",
 "is_knockout": "1 if knock_out flag set or stage in Final/Qualifier/Eliminator/Semi Final.",
 "venue_id": "Venue key.", "venue_country": "Venue country.",
 "innings": "1 = batting first, 2 = chasing. Super-over innings (3,4) are EXCLUDED.",
 "innings_ball_num": "Delivery sequence in innings (counts every delivery incl. wides/no-balls).",
 "overid": "Over number, 1-20.", "over_ball_num": "Delivery number within the over (can exceed 6).",
 "phase": "PP (overs 1-6), MID (7-15), DEATH (16-20). Fixed by over number even in shortened matches.",
 "batting_team_id": "Batting team key.", "bowling_team_id": "Bowling team key.",
 "batting_team": "Batting team name.", "bowling_team": "Bowling team name.",
 # players
 "striker_id": "Batter on strike (use IDs, not names: 3 names map to 2 players).",
 "striker_name": "Name as in ball_by_ball.", "non_striker_id": "Non-striker key.",
 "bowler_id": "Bowler key.", "bowler_name": "Name as in ball_by_ball.",
 "batting_type": "RHB / LHB.", "bowling_type": "Bowling style text.", "pace_or_spin": "Pace / Spin.",
 "batting_order": "Striker's batting position (1-11).",
 "striker_is_impact": "1 if striker was an IPL Impact Player substitute in this match.",
 "bowler_is_impact": "1 if bowler was an Impact Player substitute in this match.",
 "stroke": "Shot played (3% missing). Not used in shared features.",
 # delivery outcome
 "bat_runs": "Runs off the bat (source column `runs`; includes runs off no-balls).",
 "extras_runs": "extras1_runs + extras_2_runs.",
 "total_runs": "bat_runs + extras_runs = runs added to team total.",
 "bowler_runs": "Runs charged to bowler: bat_runs + (extras1 on wides/no-balls). Byes, leg-byes, penalty excluded. Caveat: extras_2 on no-balls (48 runs in data) not charged.",
 "extras_type": "Source extras type (wide, Overstep, other, byes, legbyes, Penalty).",
 "is_wide": "1 if wide.", "is_noball": "1 if no-ball (extras_type 'Overstep' or 'other'; 'other' verified to behave as a no-ball).",
 "is_legal": "1 if neither wide nor no-ball. Exactly 120 legal balls = full T20 innings.",
 "batter_faced": "1 if delivery counts as a ball faced by striker (everything except wides).",
 "is_bat_four": "1 if bat_runs==4 and flagged four.", "is_bat_six": "1 if bat_runs==6 and flagged six.",
 "is_dot_batter": "1 if batter_faced and bat_runs==0 (includes bye/leg-bye balls).",
 "is_dot_bowler": "1 if legal and bowler_runs==0.",
 "is_wicket": "1 if any wicket fell on the delivery (team-level wicket, incl. run-outs, retired out).",
 "dismissal_type": "Source dismissal text.",
 "dismissed_player_id": "Player dismissed (may be non-striker on run-outs).",
 "bowler_wicket": "1 if wicket credited to bowler (Caught, Bowled, LBW, Stump, Hit Wicket). Run-outs/retired/obstructing excluded.",
 "striker_dismissed": "1 if the striker was dismissed (excl. Retire Out).",
 "nonstriker_dismissed": "1 if the non-striker was dismissed (non-striker run-outs).",
 # state BEFORE the delivery
 "cum_runs_before": "Team runs before this delivery.",
 "wkts_before": "Team wickets fallen before this delivery.",
 "wkts_in_hand": "10 - wkts_before.",
 "legal_balls_before": "Legal balls bowled in innings before this delivery.",
 "innings_balls_limit": "Legal balls available in the innings (120, or revised balls if rain/DLS; revised_overs fields are in BALLS).",
 "balls_left": "innings_balls_limit - legal_balls_before (floored at 0).",
 "is_shortened": "1 if innings_balls_limit < 120 (rain/DLS). Phase/par less meaningful - consider excluding.",
 "crr": "Current run rate (runs per over) before delivery; NaN at first ball.",
 "target": "Chase only: revised_target if given, else first-innings total + 1. NaN in innings 1.",
 "runs_needed": "Chase only: target - cum_runs_before.",
 "rrr": "Chase only: required run rate (runs per over) = runs_needed / balls_left * 6. Uncapped; NaN if balls_left == 0.",
 "rrr_minus_crr": "Chase only: rrr - crr.",
 "runs_needed_per_wkt_in_hand": "Chase only: runs_needed / wkts_in_hand.",
 "par_runs": "Innings 1 only: mean team score at the same legal-ball count in full-length innings of the same comp_group (all-out innings carried forward at final total). Descriptive benchmark, includes the match itself (negligible leakage).",
 "score_vs_par": "Innings 1 only: cum_runs_before - par_runs.",
 "proj_score_crr": "Innings 1 only: cum_runs_before + crr * balls_left / 6; NaN at first ball.",
 # flags
 "match_complete": "1 if both innings present AND result is a win/tie. RECOMMENDED DEFAULT FILTER for pressure work.",
 "has_chase_data": "1 if the match has a second innings in the data.",
 # hindsight (ex-post) - using these as 'pressure' inputs = outcome leakage; fine for validation
 "hs_innings_total": "HINDSIGHT. Final total of this innings.",
 "hs_first_inn_total": "HINDSIGHT. First innings final total of the match.",
 "hs_batting_team_won": "HINDSIGHT. 1/0 whether batting team won; NaN if no result.",
 "hs_margin_type": "HINDSIGHT. runs / wickets / tie / none (parsed from result text).",
 "hs_margin_value": "HINDSIGHT. Margin size.",
 "hs_chase_balls_left_at_end": "HINDSIGHT. Chase only: legal balls left when innings ended.",
 "hs_decided_super_over": "HINDSIGHT. 1 if the match went to a super over.",
}


def sha256(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(chunk), b""):
            h.update(blk)
    return h.hexdigest()


def mode_or_nan(s):
    s = s.dropna()
    return s.mode().iat[0] if len(s) else np.nan


# ----------------------------------------------------------------------------
# 1. LOAD
# ----------------------------------------------------------------------------
def load_raw(data_dir: Path):
    raw = {n: pd.read_csv(data_dir / f"{n}.csv") for n in RAW_FILES}
    return raw


# ----------------------------------------------------------------------------
# 2. MATCH TABLE
# ----------------------------------------------------------------------------
def parse_result(res, win_team_id):
    """-> (result_class, margin_type, margin_value, dls_flag)"""
    if pd.isna(res):
        return ("unknown", "none", np.nan, 0)
    t = str(res).lower()
    dls = int(("d/l" in t) or ("dls" in t) or ("duckworth" in t))
    if "no result" in t or "abandon" in t:
        return ("no_result", "none", np.nan, dls)
    if "tie" in t:
        return ("tie", "tie", np.nan, dls)
    mt = re.search(r"(\d+)\s*(runs?|wickets?|wkts?)", t)
    if mt:
        typ = "runs" if mt.group(2).startswith("run") else "wickets"
        return ("result", typ, float(mt.group(1)), dls)
    return ("result" if pd.notna(win_team_id) else "unknown", "none", np.nan, dls)


def build_match_table(raw):
    m, c, t = raw["matches"].copy(), raw["competitions"], raw["teams"]
    m = m.merge(c, on="comp_id", how="left")
    m["match_date"] = pd.to_datetime(m["match_date"])
    m["season_year"] = m["match_date"].dt.year
    m["comp_group"] = np.where(m.comp_name.str.startswith("IPL"), "IPL",
                      np.where(m.match_format == "T20I", "T20I", "OTHER_T20"))
    m["is_knockout"] = ((m.knock_out == 1) |
                        m.stage.isin(["Final", "Qualifier", "Eliminator", "Semi Final"])).astype(int)
    parsed = [parse_result(r, w) for r, w in zip(m.result, m.win_team_id)]
    m["result_class"] = [p[0] for p in parsed]
    m["margin_type"] = [p[1] for p in parsed]
    m["margin_value"] = [p[2] for p in parsed]
    m["dls_in_result_text"] = [p[3] for p in parsed]
    # revised "overs" columns are in BALLS (114, 84, 66, 42, 48 ...)
    m["lim1"] = m.first_inn_revised_overs.fillna(CFG["T20_BALLS"])
    m["lim2"] = m.second_inn_revised_overs.fillna(m.first_inn_revised_overs).fillna(CFG["T20_BALLS"])
    # team names: verify team_id -> name is unique
    tn = t.groupby("team_id").team_name.nunique()
    assert (tn == 1).all(), "team_id maps to multiple names"
    team_map = t.drop_duplicates("team_id").set_index("team_id").team_name.to_dict()
    return m, team_map


# ----------------------------------------------------------------------------
# 3. BALL FEATURES
# ----------------------------------------------------------------------------
def build_ball_features(raw, M, team_map, qc):
    b = raw["ball_by_ball"].copy()
    qc["raw_ball_rows"] = len(b)
    qc["raw_matches_in_bbb"] = b.match_id.nunique()
    qc["super_over_rows_dropped"] = int((b.innings > 2).sum())
    qc["dup_ball_keys"] = int(b.duplicated(["match_id", "innings", "innings_ball_num"]).sum())
    b = b[b.innings <= 2].copy()

    mcols = ["match_id", "comp_id", "comp_name", "comp_group", "season_year", "match_date", "stage",
             "is_knockout", "venue_id", "venue_country", "win_team_id", "result_class",
             "margin_type", "margin_value", "lim1", "lim2", "revised_target"]
    b = b.merge(M[mcols], on="match_id", how="left", validate="m:1")
    assert b.comp_id.notna().all(), "ball rows without match metadata"
    b = b.sort_values(["match_id", "innings", "innings_ball_num"]).reset_index(drop=True)

    # --- delivery outcome --------------------------------------------------
    et = b.extras_type
    b["is_wide"] = et.eq("wide").astype(int)
    b["is_noball"] = et.isin(["Overstep", "other"]).astype(int)
    b["is_legal"] = (1 - np.maximum(b.is_wide, b.is_noball)).astype(int)
    b["batter_faced"] = (1 - b.is_wide).astype(int)
    b["bat_runs"] = b["runs"]
    b["extras_runs"] = b.extras1_runs + b.extras_2_runs
    b["total_runs"] = b.bat_runs + b.extras_runs
    b["bowler_runs"] = b.bat_runs + np.where((b.is_wide | b.is_noball) == 1, b.extras1_runs, 0)
    b["is_bat_four"] = (b.is_four & (b.bat_runs == 4)).astype(int)
    b["is_bat_six"] = (b.is_six & (b.bat_runs == 6)).astype(int)
    b["is_dot_batter"] = ((b.batter_faced == 1) & (b.bat_runs == 0)).astype(int)
    b["is_dot_bowler"] = ((b.is_legal == 1) & (b.bowler_runs == 0)).astype(int)
    b["is_wicket"] = b.is_wicket.astype(int)
    dt = b.dismissal_type
    retired = dt.eq("Retire Out")
    b["bowler_wicket"] = (b.is_wicket.astype(bool) & dt.isin(CFG["BOWLER_WICKET_TYPES"])).astype(int)
    b["striker_dismissed"] = (b.is_wicket.astype(bool) & (b.dismissed_player_id == b.striker_id) & ~retired).astype(int)
    b["nonstriker_dismissed"] = (b.is_wicket.astype(bool) & (b.dismissed_player_id == b.non_striker_id) & ~retired).astype(int)
    qc["boundary_flag_mismatch"] = int(((b.is_four & (b.bat_runs != 4)) | (b.is_six & (b.bat_runs != 6))).sum())

    # --- innings-level state ----------------------------------------------
    g = b.groupby(["match_id", "innings"], sort=False)
    b["cum_runs_before"] = g.total_runs.cumsum() - b.total_runs
    b["wkts_before"] = g.is_wicket.cumsum() - b.is_wicket
    b["legal_balls_before"] = g.is_legal.cumsum() - b.is_legal
    b["wkts_in_hand"] = 10 - b.wkts_before
    b["innings_balls_limit"] = np.where(b.innings == 1, b.lim1, b.lim2).astype(int)
    b["balls_left"] = (b.innings_balls_limit - b.legal_balls_before).clip(lower=0)
    b["is_shortened"] = (b.innings_balls_limit < CFG["T20_BALLS"]).astype(int)
    b["crr"] = np.where(b.legal_balls_before > 0, b.cum_runs_before / b.legal_balls_before.replace(0, np.nan) * 6, np.nan)

    lo = {k: v for k, v in CFG["PHASE_OVERS"].items()}
    b["phase"] = np.select([b.overid <= lo["PP"][1], b.overid <= lo["MID"][1]], ["PP", "MID"], "DEATH")

    # --- innings summaries -------------------------------------------------
    inn = g.agg(hs_innings_total=("total_runs", "sum"), inn_wkts=("is_wicket", "sum"),
                inn_legal=("is_legal", "sum"), bat_team=("batting_team_id", "first"),
                bowl_team=("bowling_team_id", "first")).reset_index()
    first = inn[inn.innings == 1].set_index("match_id")
    b["hs_innings_total"] = b.set_index(["match_id", "innings"]).index.map(
        inn.set_index(["match_id", "innings"]).hs_innings_total).values
    b["hs_first_inn_total"] = b.match_id.map(first.hs_innings_total)

    # --- chase state -------------------------------------------------------
    is2 = b.innings == 2
    b["target"] = np.where(is2, np.where(b.revised_target.notna(), b.revised_target, b.hs_first_inn_total + 1), np.nan)
    b["runs_needed"] = np.where(is2, b.target - b.cum_runs_before, np.nan)
    ok = is2 & (b.balls_left > 0)
    b["rrr"] = np.where(ok, b.runs_needed / b.balls_left.replace(0, np.nan) * 6, np.nan)
    b["rrr_minus_crr"] = b.rrr - b.crr
    b["runs_needed_per_wkt_in_hand"] = np.where(is2 & (b.wkts_in_hand > 0), b.runs_needed / b.wkts_in_hand.replace(0, np.nan), np.nan)

    # --- innings-1 par curve (survivor-bias safe: all-out innings carried forward)
    full1 = b[(b.innings == 1) & (b.innings_balls_limit == CFG["T20_BALLS"])].copy()
    full1["lba"] = full1.legal_balls_before + full1.is_legal
    last = full1.groupby(["match_id", "lba"]).apply(lambda d: (d.cum_runs_before + d.total_runs).max(), include_groups=False)
    grid = last.unstack("lba").reindex(columns=range(0, CFG["T20_BALLS"] + 1))
    grid[0] = 0
    grid = grid.ffill(axis=1)
    cg = M.set_index("match_id").comp_group
    grid["cg"] = grid.index.map(cg)
    n_by_cg = grid.cg.value_counts()
    par_all = grid.drop(columns="cg").mean()
    par = {k: grid[grid.cg == k].drop(columns="cg").mean() if n_by_cg.get(k, 0) >= CFG["PAR_MIN_INNINGS"] else par_all
           for k in ["IPL", "T20I", "OTHER_T20"]}
    qc["par_innings_by_group"] = {k: int(v) for k, v in n_by_cg.items()}
    par_arr = pd.DataFrame(par)  # index = legal balls, cols = groups
    idx = np.clip(b.legal_balls_before.values, 0, CFG["T20_BALLS"])
    par_vals = np.array([par_arr.at[i, g_] for i, g_ in zip(idx, b.comp_group)])
    is1 = (b.innings == 1) & (b.is_shortened == 0)
    b["par_runs"] = np.where(is1, par_vals, np.nan)
    b["score_vs_par"] = b.cum_runs_before - b.par_runs
    b["proj_score_crr"] = np.where(b.innings == 1, b.cum_runs_before + b.crr * b.balls_left / 6, np.nan)

    # --- match-level flags + hindsight -------------------------------------
    inn_cnt = inn.groupby("match_id").innings.nunique()
    b["has_chase_data"] = b.match_id.map(inn_cnt).ge(2).astype(int)
    b["match_complete"] = ((b.has_chase_data == 1) & b.result_class.isin(["result", "tie"])).astype(int)
    b["hs_batting_team_won"] = np.where(b.win_team_id.isna(), np.nan, (b.win_team_id == b.batting_team_id).astype(float))
    b["hs_margin_type"] = b.margin_type
    b["hs_margin_value"] = b.margin_value
    so_matches = set(raw["ball_by_ball"].loc[raw["ball_by_ball"].innings > 2, "match_id"])
    b["hs_decided_super_over"] = b.match_id.isin(so_matches).astype(int)
    lim_by = b.groupby(["match_id", "innings"]).innings_balls_limit.first()
    legal_by = inn.set_index(["match_id", "innings"]).inn_legal
    left = (lim_by - legal_by).clip(lower=0)
    key = pd.MultiIndex.from_arrays([b.match_id, b.innings])
    b["hs_chase_balls_left_at_end"] = np.where(is2, left.reindex(key).values, np.nan)

    # --- names, teams, impact flags ----------------------------------------
    b["batting_team"] = b.batting_team_id.map(team_map)
    b["bowling_team"] = b.bowling_team_id.map(team_map)
    pe = (raw["playing_eleven"].groupby(["match_id", "player_id"]).is_impact.max().astype(int))
    b["striker_is_impact"] = pe.reindex(pd.MultiIndex.from_arrays([b.match_id, b.striker_id])).fillna(0).astype(int).values
    b["bowler_is_impact"] = pe.reindex(pd.MultiIndex.from_arrays([b.match_id, b.bowler_id])).fillna(0).astype(int).values

    # --- QC on the state machine -------------------------------------------
    qc["innings_legal_gt_limit"] = int((inn.merge(lim_by.rename("lim").reset_index(), on=["match_id", "innings"])
                                        .eval("inn_legal > lim")).sum())
    qc["innings_rows"] = len(inn)
    # target-reconstruction validation against recorded winner
    chase = inn[inn.innings == 2].set_index("match_id")
    mm = M.set_index("match_id")
    v = chase.join(mm[["win_team_id", "result_class", "revised_target"]], how="left").join(
        first.hs_innings_total.rename("t1"))
    so_flag = v.index.isin(so_matches)
    v["target"] = np.where(v.revised_target.notna(), v.revised_target, v.t1 + 1)
    v = v[(v.result_class == "result") & ~so_flag & (v.hs_innings_total != (v.target - 1))]
    v["derived_chase_won"] = (v.hs_innings_total >= v.target)
    v["recorded_chase_won"] = (v.win_team_id == v.bat_team)
    bad = v[v.derived_chase_won != v.recorded_chase_won]
    qc["target_validation_checked"] = int(len(v))
    qc["target_validation_mismatch"] = int(len(bad))
    qc["target_validation_mismatch_ids"] = [int(i) for i in bad.index[:25]]
    # sanity: chasing team == bowling team of innings 1
    chk = inn.pivot(index="match_id", columns="innings", values=["bat_team", "bowl_team"]).dropna()
    qc["inn2_batting_team_mismatch"] = int((chk[("bat_team", 2)] != chk[("bowl_team", 1)]).sum())
    # truncated innings (not all out, not full, not chase-won)
    inn2 = inn.merge(lim_by.rename("lim").reset_index(), on=["match_id", "innings"])
    inn2 = inn2.merge(first.hs_innings_total.rename("t1").reset_index(), on="match_id", how="left")
    done = (inn2.inn_wkts >= 10) | (inn2.inn_legal >= inn2.lim) | ((inn2.innings == 2) & (inn2.hs_innings_total > inn2.t1))
    qc["truncated_innings"] = int((~done).sum())
    qc["truncated_innings_examples"] = inn2[~done][["match_id", "innings", "inn_legal", "inn_wkts", "hs_innings_total"]].head(15).to_dict("records")

    cols = list(BALL_COLS.keys())
    missing_doc = [c for c in cols if c not in b.columns]
    assert not missing_doc, f"documented but missing: {missing_doc}"
    out = b[cols].copy()
    # round float noise
    for c in ["crr", "rrr", "rrr_minus_crr", "runs_needed_per_wkt_in_hand", "par_runs", "score_vs_par", "proj_score_crr"]:
        out[c] = out[c].round(4)
    out["match_date"] = out.match_date.dt.strftime("%Y-%m-%d")
    return out


# ----------------------------------------------------------------------------
# 4. PLAYER TABLES
# ----------------------------------------------------------------------------
def build_player_tables(B, raw, qc):
    mapping = raw["competition_team_player_mapping"]
    map_name = mapping.drop_duplicates("player_id").set_index("player_id").player_name
    since = pd.Timestamp(CFG["ACTIVE_SINCE"])
    Bd = B.assign(_d=pd.to_datetime(B.match_date))

    # ---- batting summary
    f = Bd[Bd.batter_faced == 1]
    bat = f.groupby("striker_id").agg(
        balls_faced=("batter_faced", "size"), bat_runs=("bat_runs", "sum"),
        fours=("is_bat_four", "sum"), sixes=("is_bat_six", "sum"), dots=("is_dot_batter", "sum"),
        matches_batted=("match_id", "nunique"), first_match=("_d", "min"), last_match=("_d", "max"),
        n_seasons=("season_year", "nunique"))
    dis = Bd[(Bd.is_wicket == 1) & Bd.dismissed_player_id.notna() & (Bd.dismissal_type != "Retire Out")]
    bat["dismissals"] = dis.groupby("dismissed_player_id").size().reindex(bat.index).fillna(0).astype(int)
    for gname in ["IPL", "T20I", "OTHER_T20"]:
        bat[f"balls_faced_{gname.lower()}"] = f[f.comp_group == gname].groupby("striker_id").size().reindex(bat.index).fillna(0).astype(int)
    bat["strike_rate"] = (bat.bat_runs / bat.balls_faced * 100).round(2)
    bat["bat_avg"] = (bat.bat_runs / bat.dismissals.replace(0, np.nan)).round(2)
    bat["boundary_pct"] = ((bat.fours + bat.sixes) / bat.balls_faced * 100).round(2)
    bat["dot_pct"] = (bat.dots / bat.balls_faced * 100).round(2)
    bat["base_eligible_bat"] = ((bat.balls_faced >= CFG["ELIG_BAT_MIN_BALLS"]) &
                                (bat.matches_batted >= CFG["ELIG_BAT_MIN_MATCHES"])).astype(int)
    bat["active_since_2025"] = (bat.last_match >= since).astype(int)

    # ---- bowling summary
    l = Bd[Bd.is_legal == 1]
    bowl = l.groupby("bowler_id").agg(legal_balls=("is_legal", "size"), dots=("is_dot_bowler", "sum"),
                                      matches_bowled=("match_id", "nunique"),
                                      first_match=("_d", "min"), last_match=("_d", "max"), n_seasons=("season_year", "nunique"))
    allb = Bd.groupby("bowler_id").agg(runs_conceded=("bowler_runs", "sum"), wickets=("bowler_wicket", "sum"),
                                       wides=("is_wide", "sum"), noballs=("is_noball", "sum"),
                                       fours_conceded=("is_bat_four", "sum"), sixes_conceded=("is_bat_six", "sum"))
    bowl = bowl.join(allb)
    for gname in ["IPL", "T20I", "OTHER_T20"]:
        bowl[f"legal_balls_{gname.lower()}"] = l[l.comp_group == gname].groupby("bowler_id").size().reindex(bowl.index).fillna(0).astype(int)
    bowl["economy"] = (bowl.runs_conceded / bowl.legal_balls * 6).round(2)
    bowl["bowl_avg"] = (bowl.runs_conceded / bowl.wickets.replace(0, np.nan)).round(2)
    bowl["bowl_sr"] = (bowl.legal_balls / bowl.wickets.replace(0, np.nan)).round(2)
    bowl["dot_pct"] = (bowl.dots / bowl.legal_balls * 100).round(2)
    bowl["boundary_conceded_pct"] = ((bowl.fours_conceded + bowl.sixes_conceded) / bowl.legal_balls * 100).round(2)
    bowl["base_eligible_bowl"] = ((bowl.legal_balls >= CFG["ELIG_BOWL_MIN_BALLS"]) &
                                  (bowl.matches_bowled >= CFG["ELIG_BOWL_MIN_MATCHES"])).astype(int)
    bowl["active_since_2025"] = (bowl.last_match >= since).astype(int)

    # ---- player dimension
    ids = sorted(set(B.striker_id) | set(B.bowler_id))
    nm = pd.concat([B[["striker_id", "striker_name"]].rename(columns={"striker_id": "player_id", "striker_name": "n"}),
                    B[["bowler_id", "bowler_name"]].rename(columns={"bowler_id": "player_id", "bowler_name": "n"})])
    name_bbb = nm.drop_duplicates("player_id").set_index("player_id").n
    assert (nm.groupby("player_id").n.nunique() == 1).all()
    dim = pd.DataFrame({"player_id": ids})
    dim["player_name"] = dim.player_id.map(name_bbb)
    dim["name_in_mapping"] = dim.player_id.map(map_name)
    dup_names = dim.player_name[dim.player_name.duplicated(keep=False)].unique()
    dim["display_name"] = np.where(dim.player_name.isin(dup_names), dim.player_name + " [" + dim.player_id.astype(str) + "]", dim.player_name)
    dim["name_clash_flag"] = dim.player_name.isin(dup_names).astype(int)
    dim["name_differs_from_mapping"] = ((dim.name_in_mapping.notna()) & (dim.name_in_mapping != dim.player_name)).astype(int)
    bt = B.groupby("striker_id").batting_type.agg(mode_or_nan)
    bw = B.groupby("bowler_id").agg(bowling_type=("bowling_type", mode_or_nan), pace_or_spin=("pace_or_spin", mode_or_nan))
    dim["batting_type"] = dim.player_id.map(bt)
    dim["bowling_type"] = dim.player_id.map(bw.bowling_type)
    dim["pace_or_spin"] = dim.player_id.map(bw.pace_or_spin)
    dim["median_batting_order"] = dim.player_id.map(B[B.batter_faced == 1].groupby("striker_id").batting_order.median())
    # teams
    tb = B[["striker_id", "batting_team", "match_date"]].rename(columns={"striker_id": "player_id", "batting_team": "team"})
    tw = B[["bowler_id", "bowling_team", "match_date"]].rename(columns={"bowler_id": "player_id", "bowling_team": "team"})
    tt = pd.concat([tb, tw]).drop_duplicates(["player_id", "team"])
    latest = pd.concat([tb, tw]).sort_values("match_date").groupby("player_id").team.last()
    dim["latest_team"] = dim.player_id.map(latest)
    dim["teams_played_for"] = dim.player_id.map(tt.groupby("player_id").team.apply(lambda s: "; ".join(sorted(s))))
    dim["n_ipl_matches"] = dim.player_id.map(pd.concat([B[B.comp_group == "IPL"][["striker_id", "match_id"]].rename(columns={"striker_id": "player_id"}),
                                                        B[B.comp_group == "IPL"][["bowler_id", "match_id"]].rename(columns={"bowler_id": "player_id"})]).drop_duplicates().groupby("player_id").size()).fillna(0).astype(int)
    dim["n_t20i_matches"] = dim.player_id.map(pd.concat([B[B.comp_group == "T20I"][["striker_id", "match_id"]].rename(columns={"striker_id": "player_id"}),
                                                         B[B.comp_group == "T20I"][["bowler_id", "match_id"]].rename(columns={"bowler_id": "player_id"})]).drop_duplicates().groupby("player_id").size()).fillna(0).astype(int)
    dim["base_eligible_bat"] = dim.player_id.map(bat.base_eligible_bat).fillna(0).astype(int)
    dim["base_eligible_bowl"] = dim.player_id.map(bowl.base_eligible_bowl).fillna(0).astype(int)

    bat = bat.reset_index().rename(columns={"striker_id": "player_id"})
    bowl = bowl.reset_index().rename(columns={"bowler_id": "player_id"})
    for d in (bat, bowl):
        d.insert(1, "display_name", d.player_id.map(dim.set_index("player_id").display_name))
        d["first_match"] = d.first_match.dt.strftime("%Y-%m-%d")
        d["last_match"] = d.last_match.dt.strftime("%Y-%m-%d")
    qc["name_clashes"] = dim[dim.name_clash_flag == 1][["player_id", "player_name"]].to_dict("records")
    qc["name_differs_from_mapping"] = dim[dim.name_differs_from_mapping == 1][["player_id", "player_name", "name_in_mapping"]].to_dict("records")
    return dim, bat, bowl


# ----------------------------------------------------------------------------
# 5. BASELINES + INNINGS CONTEXT
# ----------------------------------------------------------------------------
def build_baselines(B, keys):
    def stat(d):
        bf = d[d.batter_faced == 1]; lg = d[d.is_legal == 1]
        return pd.Series({
            "balls_faced": len(bf), "bat_runs": bf.bat_runs.sum(),
            "bat_strike_rate": bf.bat_runs.sum() / max(len(bf), 1) * 100,
            "bat_boundary_pct": (bf.is_bat_four.sum() + bf.is_bat_six.sum()) / max(len(bf), 1) * 100,
            "bat_dot_pct": bf.is_dot_batter.mean() * 100 if len(bf) else np.nan,
            "bat_dismissal_per_ball": bf.striker_dismissed.mean() if len(bf) else np.nan,
            "legal_balls": len(lg), "bowler_runs": d.bowler_runs.sum(),
            "bowl_economy": d.bowler_runs.sum() / max(len(lg), 1) * 6,
            "bowl_dot_pct": lg.is_dot_bowler.mean() * 100 if len(lg) else np.nan,
            "bowl_wicket_per_legal_ball": d.bowler_wicket.sum() / max(len(lg), 1),
            "team_wicket_per_legal_ball": d.is_wicket.sum() / max(len(lg), 1)})
    out = B.groupby(keys).apply(stat, include_groups=False).reset_index()
    for c in out.columns:
        if out[c].dtype.kind == "f":
            out[c] = out[c].round(5)
    return out


def build_innings_context(B, M):
    g = B.groupby(["match_id", "innings"])
    ctx = g.agg(comp_group=("comp_group", "first"), match_date=("match_date", "first"),
                batting_team=("batting_team", "first"), bowling_team=("bowling_team", "first"),
                innings_balls_limit=("innings_balls_limit", "first"), target=("target", "first"),
                total_runs=("total_runs", "sum"), wickets=("is_wicket", "sum"),
                legal_balls=("is_legal", "sum"), match_complete=("match_complete", "first"),
                hs_batting_team_won=("hs_batting_team_won", "first"),
                hs_margin_type=("hs_margin_type", "first"), hs_margin_value=("hs_margin_value", "first"),
                is_knockout=("is_knockout", "first"), is_shortened=("is_shortened", "first"),
                venue_id=("venue_id", "first")).reset_index()
    return ctx


# ----------------------------------------------------------------------------
# 6. DOCS
# ----------------------------------------------------------------------------
def write_dictionary(path):
    L = ["# Data Dictionary - shared pipeline v%s\n" % PIPELINE_VERSION,
         "## ball_features.csv.gz  (one row per delivery, super overs excluded)\n",
         "State columns describe the situation **before** the delivery is bowled. "
         "Columns prefixed `hs_` are **hindsight** (known only after the match) - do not use them as real-time pressure inputs.\n",
         "| column | description |", "|---|---|"]
    L += [f"| `{k}` | {v} |" for k, v in BALL_COLS.items()]
    L += ["", "## Other tables",
          "- `match_innings_context.csv` - one row per match-innings (totals, target, limits, flags).",
          "- `player_dim.csv` - one row per player ID (names, handedness, bowling type, teams, eligibility flags). **Always key on `player_id`.**",
          "- `player_summary_batting.csv` / `player_summary_bowling.csv` - career totals 2022+ (overall, NOT pressure-specific) with `base_eligible_*` flags.",
          "- `league_baselines_by_over.csv` / `league_baselines_by_phase.csv` - league-average batting/bowling rates by comp_group x innings x over/phase.",
          "- `pipeline_manifest.json` - checksums, row counts, frozen config.",
          "", "## Frozen conventions",
          "- Legal ball = not wide and not no-ball. Full innings = 120 legal balls.",
          "- Ball faced = anything but a wide. Bowler runs exclude byes/leg-byes/penalty.",
          "- Bowler wicket = Caught, Bowled, LBW, Stump, Hit Wicket (no run-outs).",
          "- Target = revised_target if present else first-innings total + 1. `*_revised_overs` fields in the raw data are in BALLS.",
          f"- Shared base eligibility: batters >= {CFG['ELIG_BAT_MIN_BALLS']} balls faced AND >= {CFG['ELIG_BAT_MIN_MATCHES']} matches; "
          f"bowlers >= {CFG['ELIG_BOWL_MIN_BALLS']} legal balls AND >= {CFG['ELIG_BOWL_MIN_MATCHES']} matches. "
          "Pressure-sample minimums are set by each approach."]
    Path(path).write_text("\n".join(L), encoding="utf-8")


def write_qc_report(path, qc, B, dim, bat, bowl, M):
    mc = B.drop_duplicates(["match_id"])
    L = ["# Data Quality Report - shared pipeline v%s\n" % PIPELINE_VERSION,
         "## Coverage",
         f"- Raw delivery rows: {qc['raw_ball_rows']:,}; super-over rows dropped: {qc['super_over_rows_dropped']}; output rows: {len(B):,}",
         f"- Matches in matches.csv: {len(M)}; with ball data: {qc['raw_matches_in_bbb']}; without ball data: {len(M) - qc['raw_matches_in_bbb']} "
         f"(all `{', '.join(sorted(M[~M.match_id.isin(B.match_id)].result_class.unique()))}`-type results)",
         f"- Matches flagged `match_complete`: {int(mc.match_complete.sum())} of {len(mc)}",
         f"- Matches by comp_group: {mc.comp_group.value_counts().to_dict()}",
         f"- Shortened (rain/DLS) matches: {int(mc[mc.match_id.isin(B[B.is_shortened == 1].match_id)].shape[0])}",
         f"- Duplicate delivery keys: {qc['dup_ball_keys']}",
         "", "## Validation of the rebuilt match state",
         f"- Innings with legal balls > limit: **{qc['innings_legal_gt_limit']}** (should be 0)",
         f"- Chase batting team != first-innings bowling team: **{qc['inn2_batting_team_mismatch']}** (should be 0)",
         f"- Target reconstruction: re-derived chase winner vs recorded winner on {qc['target_validation_checked']} decided matches -> "
         f"**{qc['target_validation_mismatch']} mismatches** {qc['target_validation_mismatch_ids']}",
         f"- Truncated / incomplete innings (not all-out, not full length, chase not won): {qc['truncated_innings']}",
         f"- Boundary flags disagreeing with bat runs: {qc['boundary_flag_mismatch']}",
         f"- Par-curve innings by comp_group (min {CFG['PAR_MIN_INNINGS']} else pooled): {qc['par_innings_by_group']}",
         "", "## Players",
         f"- Players: {len(dim)}; batters with data: {len(bat)}; bowlers with data: {len(bowl)}",
         f"- Base-eligible batters: **{int(bat.base_eligible_bat.sum())}**; base-eligible bowlers: **{int(bowl.base_eligible_bowl.sum())}**",
         f"- Name clashes (same name, different player_id): {qc['name_clashes']}",
         f"- Name differs between ball_by_ball and mapping file: {qc['name_differs_from_mapping']}",
         "", "## Known limitations / judgement calls",
         "- `extras_type == 'other'` treated as no-ball (264 rows) - confirmed because it restores 6 legal balls/over and <=120/innings.",
         "- `extras_2_runs` on no-balls (48 runs) not charged to the bowler.",
         "- Phase uses fixed over numbers even when the match is shortened; `is_shortened` lets you exclude those.",
         "- Wickets: `is_wicket` counts every team wicket; `bowler_wicket` and `striker_dismissed` are the attribution columns.",
         "- Truncated innings listed above may be rain/abandonment or data gaps; filter with `match_complete`.",
         f"- Truncated examples: {qc['truncated_innings_examples']}"]
    Path(path).write_text("\n".join(L), encoding="utf-8")


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip"); ap.add_argument("--data-dir"); ap.add_argument("--out", default="./shared_outputs")
    a = ap.parse_args()
    tmp = None
    if a.zip:
        tmp = tempfile.TemporaryDirectory()
        with zipfile.ZipFile(a.zip) as z:
            z.extractall(tmp.name, members=[n for n in z.namelist() if n.endswith(".csv") and "__MACOSX" not in n])
        csvs = list(Path(tmp.name).rglob("ball_by_ball.csv"))
        assert csvs, "ball_by_ball.csv not found in zip"
        data_dir = csvs[0].parent
    else:
        data_dir = Path(a.data_dir)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)

    qc = {}
    raw = load_raw(data_dir)
    M, team_map = build_match_table(raw)
    B = build_ball_features(raw, M, team_map, qc)
    dim, bat, bowl = build_player_tables(B, raw, qc)
    ctx = build_innings_context(B, M)
    bl_over = build_baselines(B, ["comp_group", "innings", "phase", "overid"])
    bl_phase = build_baselines(B, ["comp_group", "innings", "phase"])

    files = {
        "ball_features.csv.gz": lambda p: B.to_csv(p, index=False, compression="gzip"),
        "match_innings_context.csv": lambda p: ctx.to_csv(p, index=False),
        "player_dim.csv": lambda p: dim.to_csv(p, index=False),
        "player_summary_batting.csv": lambda p: bat.sort_values("balls_faced", ascending=False).to_csv(p, index=False),
        "player_summary_bowling.csv": lambda p: bowl.sort_values("legal_balls", ascending=False).to_csv(p, index=False),
        "league_baselines_by_over.csv": lambda p: bl_over.to_csv(p, index=False),
        "league_baselines_by_phase.csv": lambda p: bl_phase.to_csv(p, index=False),
    }
    for name, fn in files.items():
        fn(out / name)
    write_dictionary(out / "DATA_DICTIONARY.md")
    write_qc_report(out / "DATA_QUALITY_REPORT.md", qc, B, dim, bat, bowl, M)

    manifest = {"pipeline_version": PIPELINE_VERSION, "config": CFG,
                "python": sys.version.split()[0], "pandas": pd.__version__, "numpy": np.__version__,
                "inputs": {n: sha256(data_dir / f"{n}.csv") for n in RAW_FILES},
                "outputs": {n: {"sha256": sha256(out / n)} for n in list(files) + ["DATA_DICTIONARY.md", "DATA_QUALITY_REPORT.md"]},
                "row_counts": {"ball_features": len(B), "match_innings_context": len(ctx), "player_dim": len(dim),
                               "player_summary_batting": len(bat), "player_summary_bowling": len(bowl)}}
    (out / "pipeline_manifest.json").write_text(json.dumps(manifest, indent=2, default=str))
    print(json.dumps({"rows": manifest["row_counts"], "eligible_bat": int(bat.base_eligible_bat.sum()),
                      "eligible_bowl": int(bowl.base_eligible_bowl.sum()),
                      "target_mismatch": qc["target_validation_mismatch"], "of": qc["target_validation_checked"]}, indent=1))
    if tmp: tmp.cleanup()


if __name__ == "__main__":
    main()
