"""
Filter the full model output to the AVAILABLE POOL (e.g. post-retention auction list) and produce top-N lists.

    python select_pool.py --pool target_pool.csv --top 50
    python select_pool.py --pool target_pool.csv --top 50 --bat-role finisher --bowl-phase DEATH --origin indian --min-tier B

Pool file: CSV with a name column (header containing 'name' or 'player'; or just one column) and optionally a `player_id` column.
v3: ranking is ROBUST (ranking.py): tier penalty applied inside every bootstrap draw, ordering by the pessimistic end of the in-pool rank interval,
role gate (batter lists = batters + all-rounders, bowler lists = bowlers + all-rounders), Tier C players listed separately (watch-list).
Role comes from a `role` column in the pool file (batter / bowler / all-rounder, any spelling) when present, else player_dim.csv `role`, else usage inference.
Nothing is re-fitted: scores come from run_all.py, so every list is consistent with the methodology.  Ranks inside the pool are
recomputed; bootstrap probabilities are recomputed INSIDE the pool (P(top N in this pool), rank interval) from the stored bootstrap scores.
"""
import argparse, difflib, re, unicodedata
import numpy as np, pandas as pd
from config import CFG
import ranking as RK

OUT = CFG["OUT_DIR"]


def norm(s):
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"\s+", " ", re.sub(r"[^a-z ]", " ", s)).strip()


def build_lookup(dim):
    rows = []
    for _, r in dim.iterrows():
        for col in ("display_name", "player_name", "name_in_mapping"):
            if pd.notna(r.get(col)): rows.append((norm(r[col]), int(r.player_id)))
    lk = pd.DataFrame(rows, columns=["n", "player_id"]).drop_duplicates()
    return lk


def match_names(pool, dim):
    lk = build_lookup(dim); names = dim.set_index("player_id").display_name
    by_n = lk.groupby("n").player_id.apply(list).to_dict(); allnames = list(by_n)
    out = []
    for raw in pool["name"]:
        n = norm(raw); status, pid, how, cands = "unmatched", None, "", []
        if n in by_n:
            ids = by_n[n]
            if len(ids) == 1: status, pid, how = "matched", ids[0], "exact"
            else: status, how, cands = "AMBIGUOUS (same name, several players: give player_id)", "exact", ids
        else:
            tok = n.split()
            if len(tok) >= 2:   # 'V Kohli' vs 'Virat Kohli': same surname + same first initial
                cand = [k for k in allnames if k.split() and k.split()[-1] == tok[-1] and k[0] == tok[0][0]]
                ids = sorted({i for k in cand for i in by_n[k]})
                if len(ids) == 1: status, pid, how = "matched (check)", ids[0], "initial+surname"
                elif len(ids) > 1: status, how, cands = "AMBIGUOUS (initial+surname)", "initial+surname", ids
            if pid is None and not cands:
                close = difflib.get_close_matches(n, allnames, n=3, cutoff=0.84)
                ids = sorted({i for k in close for i in by_n[k]})
                if len(ids) == 1: status, pid, how = "matched (check)", ids[0], "fuzzy"
                elif ids: status, how, cands = "AMBIGUOUS (fuzzy)", "fuzzy", ids
        out.append(dict(input_name=raw, player_id=pid, matched_name=names.get(pid) if pid else None, method=how, status=status,
                        candidates="; ".join(f"{names.get(i)} [{i}]" for i in cands)))
    return pd.DataFrame(out)


def run(args):
    dim = pd.read_csv(f"{CFG['SHARED_DIR']}/player_dim.csv")
    raw = pd.read_csv(args.pool)
    if "player_id" in raw.columns and raw.player_id.notna().all():
        pool = raw.assign(name=raw.get("name", raw.player_id.astype(str)))
        rep = pd.DataFrame({"input_name": pool["name"], "player_id": raw.player_id.astype(int), "method": "given id", "status": "matched"})
        rep["matched_name"] = rep.player_id.map(dim.set_index("player_id").display_name)
    else:
        col = next((c for c in raw.columns if "name" in c.lower() or "player" in c.lower()), raw.columns[0])
        rep = match_names(pd.DataFrame({"name": raw[col].dropna().astype(str)}), dim)
    rep.to_csv(f"{OUT}/pool_match_report.csv", index=False)
    ids = set(rep.player_id.dropna().astype(int))
    explicit = pd.Series(dtype=object)                                         # role from pool file (preferred) or player_dim
    rcol = next((c for c in raw.columns if c.lower() in ("role", "player_role", "playing_role", "skill")), None)
    if rcol is not None:
        nm = [c for c in raw.columns if "name" in c.lower() or "player" in c.lower()]; key = "player_id" if "player_id" in raw.columns and raw.player_id.notna().all() else (nm[0] if nm else raw.columns[0])
        src = raw[[key, rcol]].dropna(subset=[key]).astype(str).drop_duplicates(key)
        if key == "player_id": explicit = pd.Series(src[rcol].values, index=src[key].astype(float).astype(int).values)
        else:
            m = dict(zip(src[key], src[rcol])); explicit = pd.Series({int(p): m.get(n) for n, p in zip(rep.input_name, rep.player_id) if pd.notna(p)})
    elif "role" in dim.columns: explicit = dim.set_index("player_id")["role"].dropna()
    print(f"pool: {len(rep)} names -> matched {len(ids)}; to confirm/resolve: {int(rep.status.str.contains('check|AMBIG|unmatched').sum())} (see pool_match_report.csv)")

    TB = pd.read_csv(f"{OUT}/rankings_batters_all.csv"); TW = pd.read_csv(f"{OUT}/rankings_bowlers_all.csv")
    roles = RK.resolve_roles(TB, TW, explicit if len(explicit) else None)
    roles.assign(player=lambda d: d.index.map(dim.set_index("player_id").display_name)).loc[sorted(ids & set(roles.index))].to_csv(f"{OUT}/pool_role_report.csv")
    for side, T, label in (("bat", TB, "batters"), ("bowl", TW, "bowlers")):
        boot = pd.read_csv(f"{OUT}/boot_scores_{label}.csv.gz", index_col=0)
        inpool = T[T.player_id.isin(ids)].copy(); n_un = len(ids - set(T.player_id))
        n0 = len(inpool); keep = RK.role_gate(list(inpool.player_id), roles, side); inpool = inpool[inpool.player_id.isin(keep)]; n_role = n0 - len(inpool)
        tiers = {"A": 3, "B": 2, "C": 1}; inpool = inpool[inpool.tier.map(tiers) >= tiers[args.min_tier]]
        score = "final"
        if side == "bat" and args.bat_role: inpool = inpool[inpool.role == args.bat_role.lower()]
        if side == "bowl":
            if args.pace_spin: inpool = inpool[inpool.pace_or_spin.str.lower().eq(args.pace_spin.lower())]
            if args.bowl_phase:
                ph = args.bowl_phase.upper(); score = f"level_{ph}"
                inpool = inpool[inpool[f"pressure_overs_{ph}"].fillna(0) >= CFG["PHASE_MIN_OVERS"]]
        if args.origin:
            key = {"indian": "Indian", "overseas": "Overseas", "unknown": "unknown"}[args.origin.lower()]
            inpool = inpool[inpool.origin_hint.str.startswith(key)]
        inpool = inpool.set_index("player_id", drop=False)
        inpool["player_role"] = roles.player_role.reindex(inpool.index).values; inpool["role_source"] = roles.role_source.reindex(inpool.index).values
        main, watch = RK.split_by_tier(inpool)
        suffix = "".join(["_" + x for x in (args.bat_role if side == "bat" else args.bowl_phase, args.pace_spin if side == "bowl" else None, args.origin) if x])
        extra = ["player_role", "role_source", "tier_penalty", "final_after_penalty", "pool_rank_best", "pool_rank_median", "pool_rank_pessimistic", f"P_top{args.top}_in_pool", "score_after_penalty_p10", "draws_with_exposure"]
        base = ["robust_rank", "player", "player_id", "ipl_team", "origin_hint", "role", "batting_type", "primary_phase", "specialist_in", "bowling_type", "pace_or_spin",
                "tier", "sample_reliability_primary", score, "final", "level", "level_serious", "level_high", "consistency", "p_balls", "p_overs", "p_balls_recent_weighted", "p_overs_recent_weighted",
                "n_high", "n_serious", "p_matches", "pressure_strike_rate", "runs_above_exp_per100_pressure", "runs_above_exp_per100_usual",
                "pressure_minus_usual_per100_raw", "pressure_minus_usual_80pct_halfwidth", "relief_rate_pct", "relief_expected_pct", "pressure_economy", "pressure_dot_pct",
                "runs_saved_per_over_pressure", "runs_saved_per_over_usual", "pressure_minus_usual_raw", "level_PP", "level_MID", "level_DEATH", "keeper_share", "last_match", "last_ipl_match"]
        for nm_, grp in (("main", main), ("watchlist", watch)):
            if not len(grp): continue
            grp = grp.drop(columns=[c for c in extra + ["robust_rank"] if c in grp.columns and c not in ("player_role", "role_source")])      # recomputed for THIS pool
            if score == "final":                                   # robust ordering (penalty inside each draw, pessimistic in-pool rank interval)
                out = grp.join(RK.robust_table(boot, inpool.tier, list(grp.index), args.top)).sort_values("robust_rank")
                out["final_after_penalty"] = (out.final - out.tier_penalty).round(2)
            else:                                                  # phase lists: no phase-specific bootstrap exists -> phase score less the tier penalty
                out = grp.assign(tier_penalty=RK.penalty(grp.tier).values); out["final_after_penalty"] = (out[score] - out.tier_penalty).round(2)
                out = out.sort_values("final_after_penalty", ascending=False); out["robust_rank"] = np.arange(1, len(out) + 1)
            cols = [c for c in base + extra if c in out.columns]; cols = list(dict.fromkeys(cols))
            fname = f"pool_top{args.top}_{label}{suffix}.csv" if nm_ == "main" else f"pool_watchlist_tierC_{label}{suffix}.csv"
            (out.head(args.top) if nm_ == "main" else out).loc[:, cols].to_csv(f"{OUT}/{fname}", index=False)
        print(f"{label}: {n0} scored pool players; {n_role} removed by role gate; {len(main)} main-list (tier A/B), {len(watch)} Tier C watch-list; "
              f"no pressure data in this discipline: {n_un} -> pool_top{args.top}_{label}{suffix}.csv")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pool", required=True); ap.add_argument("--top", type=int, default=50)
    ap.add_argument("--bat-role", choices=["top", "middle", "finisher"]); ap.add_argument("--bowl-phase", choices=["PP", "MID", "DEATH", "pp", "mid", "death"])
    ap.add_argument("--pace-spin", choices=["pace", "spin", "Pace", "Spin"]); ap.add_argument("--origin", choices=["indian", "overseas", "unknown"])
    ap.add_argument("--min-tier", default="C", choices=["A", "B", "C"], help="A = full evidence, B = moderate, C = thin (still shrunk toward average)")
    run(ap.parse_args())
