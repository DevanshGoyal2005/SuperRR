"""Stage 3 - assemble components, scores, tiers, roles, phase profiles."""
import numpy as np, pandas as pd, metrics as M
from config import CFG, FULL_MEMBERS

SIGN_BAT = dict(relief=1, runs=1, dismissal=-1, boundary=1)       # res_dis: positive = dismissed more = worse
SIGN_BOWL = dict(success=1, economy=1, wicket=1, dot=1, boundary=1)


def pct(s, pool):
    ref = np.sort(s[pool].dropna().values)
    return s.apply(lambda v: 100.0 * np.searchsorted(ref, v, side="right") / len(ref) if pd.notna(v) and len(ref) else np.nan)


def metric_pct(tab, idx, sign, pool, cfg=CFG):
    """Percentile of the shrunk value among reference-pool players; NEUTRAL 50 if the metric has no detectable between-player signal."""
    if tab.attrs.get("k", 1e6) >= cfg["K_NOSIGNAL"]:
        return pd.Series(50.0, index=idx)
    return pct(tab.shrunk.reindex(idx).fillna(0) * sign, pool)


def tier_of(n, m, A, B, scale=1.0):
    a = (n >= A[0] * scale) & (m >= A[1] * scale); b = (n >= B[0] * scale) & (m >= B[1] * scale)
    return pd.Series(np.where(a, "A", np.where(b, "B", "C")), index=n.index)


def components(D, cfg=CFG, elig_scale=1.0, venue_resid=None):
    out = {}
    # ---------------- batters
    f = M.batting_units(D, cfg, venue_resid); inn = M.batting_innings(f, cfg); bb = M.batting_scores(f, inn)
    P = f[f.band_bat != "low"]; L = f[f.band_bat == "low"]
    g = P[P.w_rec > 0].groupby("striker_id")                  # v3: exposure counted only inside the recency window (all rows when no hard cut)
    ex = pd.DataFrame({"p_balls": g.size(), "p_matches": g.match_id.nunique(), "n_high": g.band_bat.apply(lambda s: (s == "high").sum()),
                       "p_balls_recent_weighted": g.w_rec.sum().round(1)})
    ex["n_serious"] = ex.p_balls - ex.n_high
    ex["p_innings"] = inn.groupby("pid").size().reindex(ex.index).fillna(0).astype(int)
    ex["tier"] = tier_of(ex.p_balls, ex.p_matches, cfg["TIER_A_BAT"], cfg["TIER_B_BAT"], elig_scale)
    pool = ex.tier == "A"
    out.update(bat_ex=ex, bat_pool=pool, f=f, inn=inn, P=P, bat_tabs=bb)
    out["bat_pct"] = {b: pd.DataFrame({m: metric_pct(bb[b][m], ex.index, SIGN_BAT[m], pool, cfg) for m in SIGN_BAT}) for b in ("serious", "high")}
    rd = M.eb_diff(P, L, "striker_id", "res_runs"); out["bat_res_raw"] = rd.shrunk.reindex(ex.index).fillna(0); out["bat_res_tab"] = rd
    mm = P.groupby(["striker_id", "match_id", "innings"]).agg(r=("res_runs", "sum"), n=("res_runs", "size"), match_date=("match_date", "first"), w_rec=("w_rec", "first")).reset_index()
    mm = mm[mm.n >= cfg["CONS_MIN_BALLS"]].copy(); mm["hit"] = (mm.r > 0).astype(float); p0 = mm.hit.mean(); mm["res_hit"] = mm.hit - p0
    ch = M.eb(mm, "striker_id", "res_hit", min_n=5)
    out["bat_cons_raw"] = p0 + ch.shrunk.reindex(ex.index).fillna(0); out["cons_units_bat"] = mm; out["bat_cons_p0"] = p0
    out["bat_k"] = {f"{b}_{m}": bb[b][m].attrs["k"] for b in bb for m in bb[b]}
    # ---------------- bowlers
    O = M.bowling_overs(D, cfg, venue_resid); bw = M.bowling_scores(O)
    Pq = O[O.start_band != "low"]; Lw = O[O.start_band == "low"]
    gw = Pq[Pq.w_rec > 0].groupby("bowler_id")
    ew = pd.DataFrame({"p_overs": gw.size(), "p_matches": gw.match_id.nunique(), "n_high": gw.start_band.apply(lambda s: (s == "high").sum()),
                       "p_balls": gw.legal.sum(), "wkts": gw.wkts.sum(), "p_overs_recent_weighted": gw.w_rec.sum().round(1)})
    ew["n_serious"] = ew.p_overs - ew.n_high
    ew["tier"] = tier_of(ew.p_overs, ew.p_matches, cfg["TIER_A_BOWL"], cfg["TIER_B_BOWL"], elig_scale)
    poolw = ew.tier == "A"
    out.update(bowl_ex=ew, bowl_pool=poolw, O=O, Pq=Pq, bowl_tabs=bw)
    out["bowl_pct"] = {b: pd.DataFrame({m: metric_pct(bw[b][m], ew.index, SIGN_BOWL[m], poolw, cfg) for m in SIGN_BOWL}) for b in ("serious", "high")}
    rdw = M.eb_diff(Pq, Lw, "bowler_id", "res_econ"); out["bowl_res_raw"] = rdw.shrunk.reindex(ew.index).fillna(0); out["bowl_res_tab"] = rdw
    mw = Pq.groupby(["bowler_id", "match_id"]).agg(r=("res_econ", "sum"), n=("res_econ", "size"), match_date=("match_date", "first"), w_rec=("w_rec", "first")).reset_index()
    mw = mw[mw.n >= cfg["CONS_MIN_OVERS"]].copy(); mw["hit"] = (mw.r > 0).astype(float); p0w = mw.hit.mean(); mw["res_hit"] = mw.hit - p0w
    chw = M.eb(mw, "bowler_id", "res_hit", min_n=5)
    out["bowl_cons_raw"] = p0w + chw.shrunk.reindex(ew.index).fillna(0); out["cons_units_bowl"] = mw; out["bowl_cons_p0"] = p0w
    out["bowl_k"] = {f"{b}_{m}": bw[b][m].attrs["k"] for b in bw for m in bw[b]}
    return out


def combine(C, side, w_metric, band_w=None, final_w=None, cfg=CFG):
    band_w = band_w or cfg["BAND_W"]; final_w = final_w or dict(level=1.0, resilience=0.0, consistency=0.0)
    pool = C[side + "_pool"]
    bs = {b: sum(C[side + "_pct"][b][m] * wm for m, wm in w_metric.items() if wm) for b in ("serious", "high")}
    level = pct(band_w["high"] * bs["high"] + band_w["serious"] * bs["serious"], pool)
    res = pct(C[side + "_res_raw"], pool); cons = pct(C[side + "_cons_raw"], pool)
    final = final_w["level"] * level + final_w["resilience"] * res + final_w["consistency"] * cons
    t = pd.DataFrame({"final": final, "level": level, "level_serious": bs["serious"], "level_high": bs["high"], "resilience_pct": res, "consistency": cons})
    t["tier"] = C[side + "_ex"].tier
    return t.sort_values("final", ascending=False)             # ALL players with any pressure exposure (tier shows evidence quality)


def phase_profiles(O, w, cfg=CFG):
    """Bowler level score computed separately inside powerplay / middle / death overs (same method, same band mix)."""
    out = {}
    wn = {m: w.get(m, 0) for m in ("economy", "wicket", "dot")}; s_ = sum(wn.values()) or 1; wn = {m: v / s_ for m, v in wn.items()}
    for ph in ("PP", "MID", "DEATH"):
        Op = O[(O.phase == ph) & (O.start_band != "low")]
        ex = Op.groupby("bowler_id").agg(overs=("runs", "size"), high_overs=("start_band", lambda s: (s == "high").sum()))
        pool = ex.overs >= cfg["PHASE_MIN_OVERS"]; sc = {}
        for b in ("serious", "high"):
            ob = Op[Op.start_band == b]; s = 0
            for m, col in (("economy", "res_econ"), ("wicket", "res_wkt"), ("dot", "res_dot")):
                if wn[m] == 0: continue
                s = s + wn[m] * metric_pct(M.eb(ob, "bowler_id", col), ex.index, 1, pool, cfg)
            sc[b] = s
        raw = cfg["BAND_W"]["high"] * sc["high"] + cfg["BAND_W"]["serious"] * sc["serious"]
        out[ph] = pd.DataFrame({f"level_{ph}": pct(raw, pool), f"pressure_overs_{ph}": ex.overs})
    return out


# ------------------------------------------------------------------ roles / context (all situations, not only pressure)
def player_context(D, dim, cfg=CFG):
    f = D[D.batter_faced == 1]
    g = f.groupby("striker_id")
    bc = pd.DataFrame({"balls_all": g.size(), "matches_all": g.match_id.nunique(), "median_order": g.batting_order.median(),
                       "share_pp": g.phase.apply(lambda s: (s == "PP").mean()), "share_mid": g.phase.apply(lambda s: (s == "MID").mean()),
                       "share_death": g.phase.apply(lambda s: (s == "DEATH").mean()), "last_match": g.match_date.max()})
    bc["role"] = np.where(bc.median_order <= cfg["TOP_ORDER_MAX"], "top",
                  np.where((bc.median_order >= cfg["FINISHER_MIN_ORDER"]) & (bc.share_death >= cfg["FINISHER_MIN_DEATH_SHARE"]), "finisher", "middle"))
    l = D[D.is_legal == 1]; gl = l.groupby("bowler_id")
    wc = pd.DataFrame({"legal_all": gl.size(), "matches_all": gl.match_id.nunique(), "share_pp": gl.phase.apply(lambda s: (s == "PP").mean()),
                       "share_mid": gl.phase.apply(lambda s: (s == "MID").mean()), "share_death": gl.phase.apply(lambda s: (s == "DEATH").mean()),
                       "last_match": gl.match_date.max()})
    sh = wc[["share_pp", "share_mid", "share_death"]]
    wc["primary_phase"] = sh.idxmax(axis=1).str.replace("share_", "").str.upper()
    wc["specialist_in"] = sh.apply(lambda r: "+".join([p.upper() for p, v in zip(("PP", "MID", "DEATH"), r) if v >= cfg["SPECIALIST_MIN_SHARE"]]), axis=1)
    dm = dim.set_index("player_id")
    wc["bowling_type"] = dm.bowling_type.reindex(wc.index); wc["pace_or_spin"] = dm.pace_or_spin.reindex(wc.index)
    bc["batting_type"] = dm.batting_type.reindex(bc.index)
    # national team proxy (most frequent T20I team) / latest IPL franchise / keeper share
    t20 = pd.concat([D[D.comp_group == "T20I"][["striker_id", "batting_team"]].rename(columns={"striker_id": "pid", "batting_team": "t"}),
                     D[D.comp_group == "T20I"][["bowler_id", "bowling_team"]].rename(columns={"bowler_id": "pid", "bowling_team": "t"})])
    nat = t20.groupby("pid").t.agg(lambda s: s.mode().iat[0])
    ipl = pd.concat([D[D.comp_group == "IPL"][["striker_id", "batting_team", "match_date"]].rename(columns={"striker_id": "pid", "batting_team": "t"}),
                     D[D.comp_group == "IPL"][["bowler_id", "bowling_team", "match_date"]].rename(columns={"bowler_id": "pid", "bowling_team": "t"})]
                    ).sort_values("match_date").groupby("pid").agg(ipl_team=("t", "last"), last_ipl_match=("match_date", "last"))
    info = pd.DataFrame({"national_team_proxy": nat, "ipl_team": ipl.ipl_team, "last_ipl_match": ipl.last_ipl_match})
    info["origin_hint"] = np.where(info.national_team_proxy.eq("India"), "Indian (T20I for India)",
                          np.where(info.national_team_proxy.notna(), "Overseas (T20I for " + info.national_team_proxy.fillna("") + ")", "unknown (IPL-only in data)"))
    try:
        pe = pd.read_csv(f"{cfg['RAW_DIR']}/playing_eleven.csv"); pe = pe[pe.is_played == 1]
        info["keeper_share"] = pe.groupby("player_id").is_wk.mean()
    except Exception:
        info["keeper_share"] = np.nan
    return bc.join(info), wc.join(info)
